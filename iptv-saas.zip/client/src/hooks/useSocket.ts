import { useEffect, useRef, useState, useCallback } from "react";
import { io, Socket } from "socket.io-client";

interface UseSocketOptions {
  autoConnect?: boolean;
}

interface ChatMessage {
  id: number;
  conversationId: number;
  senderId: number;
  senderRole: "user" | "admin";
  message: string;
  createdAt: Date;
}

interface TypingIndicator {
  userId: number;
  role: string;
}

export function useSocket(options: UseSocketOptions = {}) {
  const { autoConnect = true } = options;
  const socketRef = useRef<Socket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [typingUsers, setTypingUsers] = useState<TypingIndicator[]>([]);

  useEffect(() => {
    if (!autoConnect) return;

    // Connect to Socket.IO server
    const socket = io({
      path: "/api/socket.io",
      withCredentials: true,
      transports: ["websocket", "polling"],
    });

    socketRef.current = socket;

    socket.on("connect", () => {
      console.log("[Socket.IO] Connected");
      setIsConnected(true);
    });

    socket.on("disconnect", () => {
      console.log("[Socket.IO] Disconnected");
      setIsConnected(false);
    });

    socket.on("message:new", (message: ChatMessage) => {
      setMessages((prev) => [...prev, message]);
    });

    socket.on("typing:start", (data: TypingIndicator) => {
      setTypingUsers((prev) => {
        if (prev.find((u) => u.userId === data.userId)) return prev;
        return [...prev, data];
      });
    });

    socket.on("typing:stop", (data: { userId: number }) => {
      setTypingUsers((prev) => prev.filter((u) => u.userId !== data.userId));
    });

    socket.on("error", (error: { message: string }) => {
      console.error("[Socket.IO] Error:", error.message);
    });

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
  }, [autoConnect]);

  const joinConversation = useCallback((conversationId: number) => {
    socketRef.current?.emit("join:conversation", conversationId);
  }, []);

  const leaveConversation = useCallback((conversationId: number) => {
    socketRef.current?.emit("leave:conversation", conversationId);
  }, []);

  const sendMessage = useCallback((conversationId: number, message: string) => {
    socketRef.current?.emit("message:send", { conversationId, message });
  }, []);

  const startTyping = useCallback((conversationId: number) => {
    socketRef.current?.emit("typing:start", conversationId);
  }, []);

  const stopTyping = useCallback((conversationId: number) => {
    socketRef.current?.emit("typing:stop", conversationId);
  }, []);

  const clearMessages = useCallback(() => {
    setMessages([]);
  }, []);

  return {
    socket: socketRef.current,
    isConnected,
    messages,
    typingUsers,
    joinConversation,
    leaveConversation,
    sendMessage,
    startTyping,
    stopTyping,
    clearMessages,
  };
}
