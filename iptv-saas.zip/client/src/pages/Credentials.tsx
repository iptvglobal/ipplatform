import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { format } from "date-fns";
import { 
  Key, 
  Copy, 
  Tv,
  Server,
  Link,
  Monitor,
  Calendar
} from "lucide-react";

export default function Credentials() {
  return (
    <AppLayout>
      <CredentialsContent />
    </AppLayout>
  );
}

function CredentialsContent() {
  const [, setLocation] = useLocation();
  const { data: credentials, isLoading } = trpc.credentials.list.useQuery();

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard!`);
  };

  const getCredentialIcon = (type: string) => {
    switch (type) {
      case "xtream":
        return <Server className="h-5 w-5" />;
      case "m3u":
        return <Link className="h-5 w-5" />;
      case "portal":
        return <Monitor className="h-5 w-5" />;
      default:
        return <Key className="h-5 w-5" />;
    }
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold">My Credentials</h1>
        <p className="text-muted-foreground mt-1">
          Access your IPTV login credentials and connection details
        </p>
      </motion.div>

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2">
          {[1, 2, 3, 4].map(i => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : credentials?.length === 0 ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card>
            <CardContent className="py-12 text-center">
              <Key className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">No credentials yet</h3>
              <p className="text-muted-foreground mb-4">
                Purchase a subscription to get your IPTV credentials
              </p>
              <Button onClick={() => setLocation("/dashboard/plans")}>
                Browse Plans
              </Button>
            </CardContent>
          </Card>
        </motion.div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {credentials?.map((cred, index) => (
            <motion.div
              key={cred.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * index }}
            >
              <Card className={!cred.isActive ? "opacity-60" : ""}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-lg">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        {getCredentialIcon(cred.type)}
                      </div>
                      <span className="capitalize">{cred.type} Credentials</span>
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">#{cred.connectionNumber}</Badge>
                      <Badge variant={cred.isActive ? "default" : "secondary"}>
                        {cred.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {cred.type === "xtream" && (
                    <>
                      <CredentialField
                        label="Server URL"
                        value={cred.serverUrl || ""}
                        onCopy={() => copyToClipboard(cred.serverUrl || "", "Server URL")}
                      />
                      <CredentialField
                        label="Username"
                        value={cred.username || ""}
                        onCopy={() => copyToClipboard(cred.username || "", "Username")}
                      />
                      <CredentialField
                        label="Password"
                        value={cred.password || ""}
                        onCopy={() => copyToClipboard(cred.password || "", "Password")}
                        masked
                      />
                    </>
                  )}

                  {cred.type === "m3u" && (
                    <CredentialField
                      label="M3U URL"
                      value={cred.m3uUrl || ""}
                      onCopy={() => copyToClipboard(cred.m3uUrl || "", "M3U URL")}
                      fullWidth
                    />
                  )}

                  {cred.type === "portal" && (
                    <>
                      <CredentialField
                        label="Portal URL"
                        value={cred.portalUrl || ""}
                        onCopy={() => copyToClipboard(cred.portalUrl || "", "Portal URL")}
                      />
                      <CredentialField
                        label="MAC Address"
                        value={cred.macAddress || ""}
                        onCopy={() => copyToClipboard(cred.macAddress || "", "MAC Address")}
                      />
                    </>
                  )}

                  {cred.expiresAt && (
                    <div className="pt-3 border-t flex items-center gap-2 text-sm text-muted-foreground">
                      <Calendar className="h-4 w-4" />
                      <span>
                        Expires: {format(new Date(cred.expiresAt), "MMMM d, yyyy")}
                      </span>
                    </div>
                  )}

                  {cred.notes && (
                    <div className="pt-3 border-t">
                      <p className="text-sm text-muted-foreground">{cred.notes}</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Help Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Tv className="h-5 w-5 text-primary" />
              How to Use Your Credentials
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-6 md:grid-cols-3">
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Server className="h-4 w-4 text-primary" />
                  Xtream Codes
                </h4>
                <p className="text-sm text-muted-foreground">
                  Enter the server URL, username, and password in your IPTV app's Xtream Codes login section.
                </p>
              </div>
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Link className="h-4 w-4 text-primary" />
                  M3U Playlist
                </h4>
                <p className="text-sm text-muted-foreground">
                  Copy the M3U URL and paste it into your IPTV player's playlist URL field.
                </p>
              </div>
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <Monitor className="h-4 w-4 text-primary" />
                  Portal (MAG/STB)
                </h4>
                <p className="text-sm text-muted-foreground">
                  Configure your MAG device with the portal URL and MAC address in the device settings.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}

interface CredentialFieldProps {
  label: string;
  value: string;
  onCopy: () => void;
  masked?: boolean;
  fullWidth?: boolean;
}

function CredentialField({ label, value, onCopy, masked, fullWidth }: CredentialFieldProps) {
  const displayValue = masked ? "••••••••" : value;
  
  return (
    <div className={fullWidth ? "space-y-1" : "flex items-center justify-between"}>
      <span className="text-sm text-muted-foreground">{label}</span>
      <div className="flex items-center gap-2">
        <code className={`text-sm bg-muted px-2 py-1 rounded ${fullWidth ? "break-all w-full block" : ""}`}>
          {displayValue}
        </code>
        <Button 
          variant="ghost" 
          size="icon" 
          className="h-8 w-8 shrink-0"
          onClick={onCopy}
        >
          <Copy className="h-3 w-3" />
        </Button>
      </div>
    </div>
  );
}
