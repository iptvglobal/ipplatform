import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { format } from "date-fns";
import { 
  Send, 
  MessageCircle,
  Loader2,
  HelpCircle,
  Mail,
  Clock
} from "lucide-react";

export default function Support() {
  return (
    <AppLayout>
      <SupportContent />
    </AppLayout>
  );
}

function SupportContent() {
  const { user } = useAuth();
  const [message, setMessage] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const { data, isLoading, refetch } = trpc.chat.getConversation.useQuery();
  const utils = trpc.useUtils();

  const sendMessageMutation = trpc.chat.sendMessage.useMutation({
    onSuccess: () => {
      setMessage("");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const markAsReadMutation = trpc.chat.markAsRead.useMutation();

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [data?.messages]);

  // Mark messages as read when conversation loads
  useEffect(() => {
    if (data?.conversation) {
      markAsReadMutation.mutate({ conversationId: data.conversation.id });
    }
  }, [data?.conversation?.id]);

  // Poll for new messages
  useEffect(() => {
    const interval = setInterval(() => {
      refetch();
    }, 5000);
    return () => clearInterval(interval);
  }, [refetch]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    sendMessageMutation.mutate({ message: message.trim() });
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold">Support</h1>
        <p className="text-muted-foreground mt-1">
          Chat with our support team for assistance
        </p>
      </motion.div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Chat Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-2"
        >
          <Card className="h-[600px] flex flex-col">
            <CardHeader className="border-b">
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5 text-primary" />
                Live Chat
              </CardTitle>
              <CardDescription>
                Our team typically responds within a few minutes
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col p-0">
              {isLoading ? (
                <div className="flex-1 p-4 space-y-4">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="flex gap-3">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <Skeleton className="h-16 w-48 rounded-lg" />
                    </div>
                  ))}
                </div>
              ) : (
                <>
                  <ScrollArea className="flex-1 p-4" ref={scrollRef}>
                    {data?.messages?.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-center">
                        <div>
                          <MessageCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                          <p className="text-muted-foreground">
                            Start a conversation with our support team
                          </p>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {data?.messages?.map((msg) => {
                          const isUser = msg.senderRole === "user";
                          return (
                            <motion.div
                              key={msg.id}
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              className={`flex gap-3 ${isUser ? "flex-row-reverse" : ""}`}
                            >
                              <Avatar className="h-8 w-8 shrink-0">
                                <AvatarFallback className={isUser ? "bg-primary text-primary-foreground" : "bg-muted"}>
                                  {isUser ? user?.name?.charAt(0) || "U" : "S"}
                                </AvatarFallback>
                              </Avatar>
                              <div className={`max-w-[70%] ${isUser ? "text-right" : ""}`}>
                                <div
                                  className={`rounded-lg px-4 py-2 inline-block ${
                                    isUser
                                      ? "bg-primary text-primary-foreground"
                                      : "bg-muted"
                                  }`}
                                >
                                  <p className="text-sm whitespace-pre-wrap">{msg.message}</p>
                                </div>
                                <p className="text-xs text-muted-foreground mt-1">
                                  {format(new Date(msg.createdAt), "h:mm a")}
                                </p>
                              </div>
                            </motion.div>
                          );
                        })}
                      </div>
                    )}
                  </ScrollArea>

                  <form onSubmit={handleSendMessage} className="p-4 border-t">
                    <div className="flex gap-2">
                      <Input
                        ref={inputRef}
                        placeholder="Type your message..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        disabled={sendMessageMutation.isPending}
                      />
                      <Button 
                        type="submit" 
                        disabled={!message.trim() || sendMessageMutation.isPending}
                      >
                        {sendMessageMutation.isPending ? (
                          <Loader2 className="h-4 w-4 animate-spin" />
                        ) : (
                          <Send className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </form>
                </>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Help Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-4"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <HelpCircle className="h-5 w-5 text-primary" />
                Quick Help
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer">
                  <h4 className="font-medium text-sm">How to set up IPTV?</h4>
                  <p className="text-xs text-muted-foreground mt-1">
                    Learn how to configure your IPTV player
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer">
                  <h4 className="font-medium text-sm">Payment issues</h4>
                  <p className="text-xs text-muted-foreground mt-1">
                    Troubleshoot payment problems
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer">
                  <h4 className="font-medium text-sm">Connection problems</h4>
                  <p className="text-xs text-muted-foreground mt-1">
                    Fix streaming and buffering issues
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Clock className="h-5 w-5 text-primary" />
                Support Hours
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Monday - Friday</span>
                  <span>9:00 AM - 10:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Saturday</span>
                  <span>10:00 AM - 8:00 PM</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Sunday</span>
                  <span>12:00 PM - 6:00 PM</span>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-4">
                All times are in UTC. Response times may vary during peak hours.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Mail className="h-5 w-5 text-primary" />
                Email Support
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                For non-urgent inquiries, you can also reach us at:
              </p>
              <p className="text-sm font-medium mt-2">support@example.com</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
