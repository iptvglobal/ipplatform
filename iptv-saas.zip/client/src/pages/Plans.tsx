import { useState } from "react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { 
  Check, 
  Tv, 
  Zap, 
  Shield, 
  Globe,
  CreditCard,
  Bitcoin,
  Loader2,
  ExternalLink
} from "lucide-react";

export default function Plans() {
  return (
    <AppLayout>
      <PlansContent />
    </AppLayout>
  );
}

function PlansContent() {
  const [, setLocation] = useLocation();
  const [selectedPlan, setSelectedPlan] = useState<number | null>(null);
  const [connections, setConnections] = useState(1);
  const [showCheckout, setShowCheckout] = useState(false);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<number | null>(null);

  const { data: plans, isLoading: plansLoading } = trpc.plans.list.useQuery();
  const { data: paymentMethods } = trpc.paymentMethods.list.useQuery();
  
  const { data: priceCalc } = trpc.plans.calculatePrice.useQuery(
    { planId: selectedPlan!, connections },
    { enabled: selectedPlan !== null }
  );

  const createOrderMutation = trpc.orders.create.useMutation({
    onSuccess: (data) => {
      toast.success("Order created successfully!");
      setShowCheckout(false);
      
      if (data.cryptoPaymentUrl) {
        window.open(data.cryptoPaymentUrl, "_blank");
      }
      
      setLocation(`/dashboard/orders/${data.orderId}`);
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const currentPlan = plans?.find(p => p.id === selectedPlan);

  const handleSelectPlan = (planId: number) => {
    const plan = plans?.find(p => p.id === planId);
    if (plan) {
      setSelectedPlan(planId);
      setConnections(plan.minConnections);
      setShowCheckout(true);
    }
  };

  const handleCheckout = () => {
    if (!selectedPlan || !selectedPaymentMethod) {
      toast.error("Please select a payment method");
      return;
    }

    createOrderMutation.mutate({
      planId: selectedPlan,
      connections,
      paymentMethodId: selectedPaymentMethod,
    });
  };

  const getPaymentIcon = (type: string) => {
    switch (type) {
      case "crypto":
        return <Bitcoin className="h-5 w-5" />;
      default:
        return <CreditCard className="h-5 w-5" />;
    }
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold">Subscription Plans</h1>
        <p className="text-muted-foreground mt-1">
          Choose the perfect plan for your streaming needs
        </p>
      </motion.div>

      {/* Features Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid gap-4 md:grid-cols-3"
      >
        <div className="flex items-center gap-3 p-4 rounded-lg bg-primary/5 border border-primary/10">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <Zap className="h-5 w-5 text-primary" />
          </div>
          <div>
            <p className="font-medium">Instant Activation</p>
            <p className="text-sm text-muted-foreground">Get started immediately</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-4 rounded-lg bg-primary/5 border border-primary/10">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <Shield className="h-5 w-5 text-primary" />
          </div>
          <div>
            <p className="font-medium">Secure Payments</p>
            <p className="text-sm text-muted-foreground">Multiple payment options</p>
          </div>
        </div>

        <div className="flex items-center gap-3 p-4 rounded-lg bg-primary/5 border border-primary/10">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
            <Globe className="h-5 w-5 text-primary" />
          </div>
          <div>
            <p className="font-medium">Global Coverage</p>
            <p className="text-sm text-muted-foreground">Channels worldwide</p>
          </div>
        </div>
      </motion.div>

      {/* Plans Grid */}
      {plansLoading ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map(i => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-48 mt-2" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-10 w-24" />
                <div className="space-y-2 mt-4">
                  {[1, 2, 3, 4].map(j => (
                    <Skeleton key={j} className="h-4 w-full" />
                  ))}
                </div>
              </CardContent>
              <CardFooter>
                <Skeleton className="h-10 w-full" />
              </CardFooter>
            </Card>
          ))}
        </div>
      ) : plans?.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <Tv className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No plans available at the moment</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {plans?.map((plan, index) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * (index + 1) }}
            >
              <Card className="relative h-full flex flex-col">
                {index === 1 && (
                  <Badge className="absolute -top-3 left-1/2 -translate-x-1/2">
                    Most Popular
                  </Badge>
                )}
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Tv className="h-5 w-5 text-primary" />
                    {plan.name}
                  </CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1">
                  <div className="mb-4">
                    <span className="text-3xl font-bold">${plan.basePrice}</span>
                    <span className="text-muted-foreground">/{plan.durationDays} days</span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-4">
                    +${plan.pricePerConnection}/connection
                  </p>
                  <div className="space-y-2">
                    {(plan.features as string[] || []).map((feature, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <Check className="h-4 w-4 text-primary" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                    <div className="flex items-center gap-2">
                      <Check className="h-4 w-4 text-primary" />
                      <span className="text-sm">{plan.minConnections}-{plan.maxConnections} connections</span>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    className="w-full" 
                    onClick={() => handleSelectPlan(plan.id)}
                  >
                    Select Plan
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Checkout Dialog */}
      <Dialog open={showCheckout} onOpenChange={setShowCheckout}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Complete Your Order</DialogTitle>
            <DialogDescription>
              Configure your subscription and select a payment method
            </DialogDescription>
          </DialogHeader>

          {currentPlan && (
            <div className="space-y-6">
              {/* Plan Summary */}
              <div className="p-4 rounded-lg bg-muted/50">
                <h4 className="font-medium mb-2">{currentPlan.name}</h4>
                <p className="text-sm text-muted-foreground">{currentPlan.description}</p>
              </div>

              {/* Connection Slider */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Number of Connections</Label>
                  <span className="font-bold text-lg">{connections}</span>
                </div>
                <Slider
                  value={[connections]}
                  onValueChange={([value]) => setConnections(value)}
                  min={currentPlan.minConnections}
                  max={currentPlan.maxConnections}
                  step={1}
                  className="w-full"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{currentPlan.minConnections} connection</span>
                  <span>{currentPlan.maxConnections} connections</span>
                </div>
              </div>

              {/* Price Breakdown */}
              <div className="p-4 rounded-lg border space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Base Price</span>
                  <span>${priceCalc?.basePrice.toFixed(2)}</span>
                </div>
                {connections > 1 && (
                  <div className="flex justify-between text-sm">
                    <span>Additional Connections ({connections - 1})</span>
                    <span>${((priceCalc?.pricePerConnection || 0) * (connections - 1)).toFixed(2)}</span>
                  </div>
                )}
                <div className="border-t pt-2 flex justify-between font-bold">
                  <span>Total</span>
                  <span className="text-primary">${priceCalc?.totalPrice.toFixed(2)}</span>
                </div>
              </div>

              {/* Payment Methods */}
              <div className="space-y-3">
                <Label>Payment Method</Label>
                <RadioGroup
                  value={selectedPaymentMethod?.toString()}
                  onValueChange={(value) => setSelectedPaymentMethod(parseInt(value))}
                >
                  {paymentMethods?.map((method) => (
                    <div
                      key={method.id}
                      className={`flex items-center space-x-3 p-4 rounded-lg border cursor-pointer transition-colors ${
                        selectedPaymentMethod === method.id 
                          ? "border-primary bg-primary/5" 
                          : "hover:bg-muted/50"
                      }`}
                      onClick={() => setSelectedPaymentMethod(method.id)}
                    >
                      <RadioGroupItem value={method.id.toString()} id={`method-${method.id}`} />
                      <div className="flex items-center gap-3 flex-1">
                        {getPaymentIcon(method.type)}
                        <div>
                          <Label htmlFor={`method-${method.id}`} className="cursor-pointer font-medium">
                            {method.name}
                          </Label>
                          {method.type === "crypto" && (
                            <p className="text-xs text-muted-foreground">
                              Pay with Bitcoin, Ethereum, and more
                            </p>
                          )}
                        </div>
                      </div>
                      {method.hasLink && method.paymentLink && (
                        <ExternalLink className="h-4 w-4 text-muted-foreground" />
                      )}
                    </div>
                  ))}
                </RadioGroup>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCheckout(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleCheckout}
              disabled={!selectedPaymentMethod || createOrderMutation.isPending}
            >
              {createOrderMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  Complete Order - ${priceCalc?.totalPrice.toFixed(2)}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
