import { useState } from "react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { 
  Package, 
  Plus,
  Pencil,
  Trash2,
  Loader2
} from "lucide-react";

export default function AdminPlans() {
  return (
    <AppLayout isAdmin>
      <AdminPlansContent />
    </AppLayout>
  );
}

function AdminPlansContent() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingPlan, setEditingPlan] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    basePrice: "",
    pricePerConnection: "",
    minConnections: 1,
    maxConnections: 10,
    durationDays: 30,
    features: "",
    isActive: true,
    sortOrder: 0,
  });

  const { data: plans, isLoading, refetch } = trpc.admin.plans.list.useQuery();
  
  const createMutation = trpc.admin.plans.create.useMutation({
    onSuccess: () => {
      toast.success("Plan created successfully");
      setShowDialog(false);
      resetForm();
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const updateMutation = trpc.admin.plans.update.useMutation({
    onSuccess: () => {
      toast.success("Plan updated successfully");
      setShowDialog(false);
      resetForm();
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const deleteMutation = trpc.admin.plans.delete.useMutation({
    onSuccess: () => {
      toast.success("Plan deleted successfully");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const resetForm = () => {
    setEditingPlan(null);
    setFormData({
      name: "",
      description: "",
      basePrice: "",
      pricePerConnection: "",
      minConnections: 1,
      maxConnections: 10,
      durationDays: 30,
      features: "",
      isActive: true,
      sortOrder: 0,
    });
  };

  const handleEdit = (plan: any) => {
    setEditingPlan(plan);
    setFormData({
      name: plan.name,
      description: plan.description || "",
      basePrice: plan.basePrice,
      pricePerConnection: plan.pricePerConnection,
      minConnections: plan.minConnections,
      maxConnections: plan.maxConnections,
      durationDays: plan.durationDays,
      features: (plan.features as string[] || []).join("\n"),
      isActive: plan.isActive,
      sortOrder: plan.sortOrder,
    });
    setShowDialog(true);
  };

  const handleSubmit = () => {
    const features = formData.features.split("\n").filter(f => f.trim());
    
    if (editingPlan) {
      updateMutation.mutate({
        id: editingPlan.id,
        name: formData.name,
        description: formData.description || undefined,
        basePrice: formData.basePrice,
        pricePerConnection: formData.pricePerConnection,
        minConnections: formData.minConnections,
        maxConnections: formData.maxConnections,
        durationDays: formData.durationDays,
        features,
        isActive: formData.isActive,
        sortOrder: formData.sortOrder,
      });
    } else {
      createMutation.mutate({
        name: formData.name,
        description: formData.description || undefined,
        basePrice: formData.basePrice,
        pricePerConnection: formData.pricePerConnection,
        minConnections: formData.minConnections,
        maxConnections: formData.maxConnections,
        durationDays: formData.durationDays,
        features,
        isActive: formData.isActive,
        sortOrder: formData.sortOrder,
      });
    }
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this plan?")) {
      deleteMutation.mutate({ id });
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold">Plan Management</h1>
          <p className="text-muted-foreground mt-1">
            Create and manage subscription plans
          </p>
        </div>
        <Button onClick={() => { resetForm(); setShowDialog(true); }}>
          <Plus className="h-4 w-4 mr-2" />
          Add Plan
        </Button>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Subscription Plans
            </CardTitle>
            <CardDescription>
              {plans?.length || 0} plans configured
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map(i => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : plans?.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No plans created yet. Click "Add Plan" to create one.
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Base Price</TableHead>
                    <TableHead>Per Connection</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Connections</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-[100px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {plans?.map((plan) => (
                    <TableRow key={plan.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium">{plan.name}</p>
                          {plan.description && (
                            <p className="text-xs text-muted-foreground truncate max-w-[200px]">
                              {plan.description}
                            </p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">${plan.basePrice}</TableCell>
                      <TableCell>${plan.pricePerConnection}</TableCell>
                      <TableCell>{plan.durationDays} days</TableCell>
                      <TableCell>{plan.minConnections}-{plan.maxConnections}</TableCell>
                      <TableCell>
                        <Badge variant={plan.isActive ? "default" : "secondary"}>
                          {plan.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleEdit(plan)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleDelete(plan.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Plan Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingPlan ? "Edit Plan" : "Create Plan"}</DialogTitle>
            <DialogDescription>
              {editingPlan ? "Update plan details" : "Add a new subscription plan"}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Plan Name</Label>
              <Input
                placeholder="e.g., Basic, Premium, Enterprise"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                placeholder="Brief description of the plan"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={2}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Base Price ($)</Label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="9.99"
                  value={formData.basePrice}
                  onChange={(e) => setFormData({ ...formData, basePrice: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <Label>Price Per Connection ($)</Label>
                <Input
                  type="number"
                  step="0.01"
                  placeholder="2.00"
                  value={formData.pricePerConnection}
                  onChange={(e) => setFormData({ ...formData, pricePerConnection: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Duration (days)</Label>
                <Input
                  type="number"
                  value={formData.durationDays}
                  onChange={(e) => setFormData({ ...formData, durationDays: parseInt(e.target.value) || 30 })}
                />
              </div>
              <div className="space-y-2">
                <Label>Min Connections</Label>
                <Input
                  type="number"
                  min="1"
                  value={formData.minConnections}
                  onChange={(e) => setFormData({ ...formData, minConnections: parseInt(e.target.value) || 1 })}
                />
              </div>
              <div className="space-y-2">
                <Label>Max Connections</Label>
                <Input
                  type="number"
                  min="1"
                  value={formData.maxConnections}
                  onChange={(e) => setFormData({ ...formData, maxConnections: parseInt(e.target.value) || 10 })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Features (one per line)</Label>
              <Textarea
                placeholder="HD Quality&#10;24/7 Support&#10;All Channels"
                value={formData.features}
                onChange={(e) => setFormData({ ...formData, features: e.target.value })}
                rows={4}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Active</Label>
                <p className="text-xs text-muted-foreground">
                  Show this plan to customers
                </p>
              </div>
              <Switch
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} disabled={isPending || !formData.name || !formData.basePrice}>
              {isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : editingPlan ? (
                "Update Plan"
              ) : (
                "Create Plan"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
