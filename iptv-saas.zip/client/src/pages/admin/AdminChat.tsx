import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "sonner";
import { format } from "date-fns";
import { 
  MessageCircle, 
  Send,
  Loader2,
  User,
  Clock
} from "lucide-react";

export default function AdminChat() {
  return (
    <AppLayout isAdmin>
      <AdminChatContent />
    </AppLayout>
  );
}

function AdminChatContent() {
  const [selectedConversation, setSelectedConversation] = useState<any>(null);
  const [message, setMessage] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data: conversations, isLoading, refetch: refetchConversations } = trpc.admin.chat.conversations.useQuery();
  
  const { data: messages, refetch: refetchMessages } = trpc.admin.chat.messages.useQuery(
    { conversationId: selectedConversation?.id },
    { enabled: !!selectedConversation }
  );

  const sendMessageMutation = trpc.admin.chat.reply.useMutation({
    onSuccess: () => {
      setMessage("");
      refetchMessages();
    },
    onError: (error: any) => {
      toast.error(error.message);
    },
  });

  // Mark as read handled by getMessages

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  // Mark as read when selecting conversation
  useEffect(() => {
    if (selectedConversation) {
      // Messages marked as read when fetched
    }
  }, [selectedConversation?.id]);

  // Poll for new messages
  useEffect(() => {
    const interval = setInterval(() => {
      refetchConversations();
      if (selectedConversation) {
        refetchMessages();
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [refetchConversations, refetchMessages, selectedConversation]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !selectedConversation) return;
    sendMessageMutation.mutate({
      conversationId: selectedConversation.id,
      message: message.trim(),
    });
  };

  const unreadCount = conversations?.filter((c: any) => c.unreadCount > 0).length || 0;

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold">Support Chat</h1>
        <p className="text-muted-foreground mt-1">
          Manage customer support conversations
          {unreadCount > 0 && (
            <Badge className="ml-2 bg-red-500">{unreadCount} unread</Badge>
          )}
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid gap-6 lg:grid-cols-3 h-[600px]"
      >
        {/* Conversations List */}
        <Card className="lg:col-span-1 flex flex-col">
          <CardHeader className="border-b py-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <MessageCircle className="h-5 w-5" />
              Conversations
            </CardTitle>
          </CardHeader>
          <CardContent className="flex-1 p-0 overflow-hidden">
            {isLoading ? (
              <div className="p-4 space-y-3">
                {[1, 2, 3, 4].map(i => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : conversations?.length === 0 ? (
              <div className="p-4 text-center text-muted-foreground">
                No conversations yet
              </div>
            ) : (
              <ScrollArea className="h-full">
                <div className="divide-y">
                  {conversations?.map((conv: any) => (
                    <button
                      key={conv.id}
                      onClick={() => setSelectedConversation(conv)}
                      className={`w-full p-4 text-left hover:bg-muted/50 transition-colors ${
                        selectedConversation?.id === conv.id ? "bg-muted" : ""
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <Avatar className="h-10 w-10">
                          <AvatarFallback>
                            <User className="h-5 w-5" />
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <p className="font-medium truncate">
                              User #{conv.userId}
                            </p>
                            {conv.unreadCount > 0 && (
                              <Badge className="bg-red-500 ml-2">
                                {conv.unreadCount}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground truncate">
                            {conv.lastMessage || "No messages yet"}
                          </p>
                          <p className="text-xs text-muted-foreground mt-1">
                            {format(new Date(conv.updatedAt), "MMM d, h:mm a")}
                          </p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        {/* Chat Area */}
        <Card className="lg:col-span-2 flex flex-col">
          {selectedConversation ? (
            <>
              <CardHeader className="border-b py-4">
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarFallback>
                      <User className="h-5 w-5" />
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-lg">
                      User #{selectedConversation.userId}
                    </CardTitle>
                    <CardDescription className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      Started {format(new Date(selectedConversation.createdAt), "MMM d, yyyy")}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col p-0 overflow-hidden">
                <ScrollArea className="flex-1 p-4" ref={scrollRef}>
                  {messages?.length === 0 ? (
                    <div className="h-full flex items-center justify-center text-muted-foreground">
                      No messages in this conversation
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {messages?.map((msg: any) => {
                        const isAdmin = msg.senderRole === "admin" || msg.senderRole === "agent";
                        return (
                          <motion.div
                            key={msg.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            className={`flex gap-3 ${isAdmin ? "flex-row-reverse" : ""}`}
                          >
                            <Avatar className="h-8 w-8 shrink-0">
                              <AvatarFallback className={isAdmin ? "bg-primary text-primary-foreground" : "bg-muted"}>
                                {isAdmin ? "A" : "U"}
                              </AvatarFallback>
                            </Avatar>
                            <div className={`max-w-[70%] ${isAdmin ? "text-right" : ""}`}>
                              <div
                                className={`rounded-lg px-4 py-2 inline-block ${
                                  isAdmin
                                    ? "bg-primary text-primary-foreground"
                                    : "bg-muted"
                                }`}
                              >
                                <p className="text-sm whitespace-pre-wrap">{msg.message}</p>
                              </div>
                              <p className="text-xs text-muted-foreground mt-1">
                                {format(new Date(msg.createdAt), "h:mm a")}
                              </p>
                            </div>
                          </motion.div>
                        );
                      })}
                    </div>
                  )}
                </ScrollArea>

                <form onSubmit={handleSendMessage} className="p-4 border-t">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Type your reply..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      disabled={sendMessageMutation.isPending}
                    />
                    <Button 
                      type="submit" 
                      disabled={!message.trim() || sendMessageMutation.isPending}
                    >
                      {sendMessageMutation.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <Send className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </>
          ) : (
            <CardContent className="flex-1 flex items-center justify-center">
              <div className="text-center text-muted-foreground">
                <MessageCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Select a conversation to view messages</p>
              </div>
            </CardContent>
          )}
        </Card>
      </motion.div>
    </div>
  );
}
