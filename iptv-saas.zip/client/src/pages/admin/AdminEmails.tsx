import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { 
  Mail, 
  Pencil,
  Loader2,
  Eye,
  Code
} from "lucide-react";

export default function AdminEmails() {
  return (
    <AppLayout isAdmin>
      <AdminEmailsContent />
    </AppLayout>
  );
}

function AdminEmailsContent() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<any>(null);
  const [formData, setFormData] = useState({
    subject: "",
    htmlContent: "",
    textContent: "",
    isActive: true,
  });
  const [previewMode, setPreviewMode] = useState<"html" | "text">("html");

  const { data: templates, isLoading, refetch } = trpc.admin.emailTemplates.list.useQuery();
  
  const updateMutation = trpc.admin.emailTemplates.update.useMutation({
    onSuccess: () => {
      toast.success("Template updated successfully");
      setShowDialog(false);
      refetch();
    },
    onError: (error: any) => {
      toast.error(error.message);
    },
  });

  const handleEdit = (template: any) => {
    setEditingTemplate(template);
    setFormData({
      subject: template.subject,
      htmlContent: template.htmlContent || "",
      textContent: template.textContent || "",
      isActive: template.isActive,
    });
    setShowDialog(true);
  };

  const handleSubmit = () => {
    if (!editingTemplate) return;
    updateMutation.mutate({
      name: editingTemplate.type,
      subject: formData.subject,
      htmlContent: formData.htmlContent,
      textContent: formData.textContent,
    });
  };

  const getTemplateTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      verification: "Email Verification",
      password_reset: "Password Reset",
      welcome: "Welcome Email",
      order_confirmation: "Order Confirmation",
      payment_received: "Payment Received",
      credentials_assigned: "Credentials Assigned",
    };
    return labels[type] || type || 'Unknown';
  };

  const getTemplateVariables = (type: string) => {
    const variables: Record<string, string[]> = {
      verification: ["{{name}}", "{{verification_link}}", "{{code}}"],
      password_reset: ["{{name}}", "{{reset_link}}", "{{code}}"],
      welcome: ["{{name}}"],
      order_confirmation: ["{{name}}", "{{order_number}}", "{{plan_name}}", "{{amount}}"],
      payment_received: ["{{name}}", "{{order_number}}", "{{amount}}"],
      credentials_assigned: ["{{name}}", "{{order_number}}", "{{credentials}}"],
    };
    return variables[type] || [];
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold">Email Templates</h1>
        <p className="text-muted-foreground mt-1">
          Customize email templates sent to customers
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5" />
              Email Templates
            </CardTitle>
            <CardDescription>
              {templates?.length || 0} templates configured
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3, 4].map(i => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Template</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Updated</TableHead>
                    <TableHead className="w-[80px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {templates?.map((template: any) => (
                    <TableRow key={template.id}>
                      <TableCell>
                        <p className="font-medium">{getTemplateTypeLabel(template.type)}</p>
                        <p className="text-xs text-muted-foreground">{template.type}</p>
                      </TableCell>
                      <TableCell className="max-w-[200px] truncate">
                        {template.subject}
                      </TableCell>
                      <TableCell>
                        <Badge variant={template.isActive ? "default" : "secondary"}>
                          {template.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {new Date(template.updatedAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <Button 
                          variant="ghost" 
                          size="icon"
                          onClick={() => handleEdit(template)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Edit Template Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Email Template</DialogTitle>
            <DialogDescription>
              {editingTemplate && getTemplateTypeLabel(editingTemplate.type)}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Subject Line</Label>
              <Input
                placeholder="Email subject"
                value={formData.subject}
                onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
              />
            </div>

            {editingTemplate && (
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-sm font-medium mb-2">Available Variables:</p>
                <div className="flex flex-wrap gap-2">
                  {getTemplateVariables(editingTemplate.type).map((v: string) => (
                    <Badge key={v} variant="outline" className="font-mono text-xs">
                      {v}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            <Tabs defaultValue="html" className="w-full">
              <TabsList>
                <TabsTrigger value="html" className="gap-2">
                  <Code className="h-4 w-4" />
                  HTML Content
                </TabsTrigger>
                <TabsTrigger value="text" className="gap-2">
                  <Mail className="h-4 w-4" />
                  Plain Text
                </TabsTrigger>
                <TabsTrigger value="preview" className="gap-2">
                  <Eye className="h-4 w-4" />
                  Preview
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="html" className="mt-4">
                <div className="space-y-2">
                  <Label>HTML Content</Label>
                  <Textarea
                    placeholder="<html>...</html>"
                    value={formData.htmlContent}
                    onChange={(e) => setFormData({ ...formData, htmlContent: e.target.value })}
                    rows={15}
                    className="font-mono text-sm"
                  />
                </div>
              </TabsContent>
              
              <TabsContent value="text" className="mt-4">
                <div className="space-y-2">
                  <Label>Plain Text Content</Label>
                  <Textarea
                    placeholder="Plain text version of the email..."
                    value={formData.textContent}
                    onChange={(e) => setFormData({ ...formData, textContent: e.target.value })}
                    rows={15}
                  />
                </div>
              </TabsContent>
              
              <TabsContent value="preview" className="mt-4">
                <div className="border rounded-lg p-4 bg-white min-h-[300px]">
                  <div className="mb-4 pb-4 border-b">
                    <p className="text-sm text-muted-foreground">Subject:</p>
                    <p className="font-medium">{formData.subject}</p>
                  </div>
                  <div 
                    dangerouslySetInnerHTML={{ __html: formData.htmlContent }}
                    className="prose prose-sm max-w-none"
                  />
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Active</Label>
                <p className="text-xs text-muted-foreground">
                  Enable this email template
                </p>
              </div>
              <Switch
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} disabled={updateMutation.isPending || !formData.subject}>
              {updateMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                "Save Template"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
