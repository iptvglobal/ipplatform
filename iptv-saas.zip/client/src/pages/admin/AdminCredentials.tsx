import { useState } from "react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { 
  Key, 
  Plus,
  Pencil,
  Trash2,
  Loader2,
  Copy,
  Check,
  User
} from "lucide-react";

export default function AdminCredentials() {
  return (
    <AppLayout isAdmin>
      <AdminCredentialsContent />
    </AppLayout>
  );
}

function AdminCredentialsContent() {
  const [showDialog, setShowDialog] = useState(false);
  const [editingCredential, setEditingCredential] = useState<any>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    type: "xtream" as "xtream" | "m3u" | "portal",
    username: "",
    password: "",
    serverUrl: "",
    m3uUrl: "",
    portalUrl: "",
    macAddress: "",
    maxConnections: 1,
    notes: "",
    isActive: true,
  });

  const { data: credentials, isLoading, refetch } = trpc.admin.credentials.list.useQuery();
  
  const createMutation = trpc.admin.credentials.create.useMutation({
    onSuccess: () => {
      toast.success("Credential created successfully");
      setShowDialog(false);
      resetForm();
      refetch();
    },
    onError: (error: any) => {
      toast.error(error.message);
    },
  });

  const updateMutation = trpc.admin.credentials.update.useMutation({
    onSuccess: () => {
      toast.success("Credential updated successfully");
      setShowDialog(false);
      resetForm();
      refetch();
    },
    onError: (error: any) => {
      toast.error(error.message);
    },
  });

  const deleteMutation = trpc.admin.credentials.delete.useMutation({
    onSuccess: () => {
      toast.success("Credential deleted successfully");
      refetch();
    },
    onError: (error: any) => {
      toast.error(error.message);
    },
  });

  const resetForm = () => {
    setEditingCredential(null);
    setFormData({
      type: "xtream",
      username: "",
      password: "",
      serverUrl: "",
      m3uUrl: "",
      portalUrl: "",
      macAddress: "",
      maxConnections: 1,
      notes: "",
      isActive: true,
    });
  };

  const handleEdit = (credential: any) => {
    setEditingCredential(credential);
    setFormData({
      type: credential.type,
      username: credential.username || "",
      password: credential.password || "",
      serverUrl: credential.serverUrl || "",
      m3uUrl: credential.m3uUrl || "",
      portalUrl: credential.portalUrl || "",
      macAddress: credential.macAddress || "",
      maxConnections: credential.maxConnections,
      notes: credential.notes || "",
      isActive: credential.isActive,
    });
    setShowDialog(true);
  };

  const handleSubmit = () => {
    const data: any = {
      type: formData.type,
      maxConnections: formData.maxConnections,
      notes: formData.notes || undefined,
      isActive: formData.isActive,
    };

    if (formData.type === "xtream") {
      data.username = formData.username;
      data.password = formData.password;
      data.serverUrl = formData.serverUrl;
    } else if (formData.type === "m3u") {
      data.m3uUrl = formData.m3uUrl;
    } else if (formData.type === "portal") {
      data.portalUrl = formData.portalUrl;
      data.macAddress = formData.macAddress;
    }

    if (editingCredential) {
      updateMutation.mutate({ id: editingCredential.id, ...data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
    toast.success("Copied to clipboard");
  };

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      xtream: "Xtream Codes",
      m3u: "M3U URL",
      portal: "Portal/MAC",
    };
    return labels[type] || type;
  };

  const getTypeBadgeVariant = (type: string): "default" | "secondary" | "outline" => {
    const variants: Record<string, "default" | "secondary" | "outline"> = {
      xtream: "default",
      m3u: "secondary",
      portal: "outline",
    };
    return variants[type] || "default";
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex justify-between items-center"
      >
        <div>
          <h1 className="text-3xl font-bold">IPTV Credentials</h1>
          <p className="text-muted-foreground mt-1">
            Manage IPTV credentials for customer subscriptions
          </p>
        </div>
        <Button onClick={() => { resetForm(); setShowDialog(true); }}>
          <Plus className="h-4 w-4 mr-2" />
          Add Credential
        </Button>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Key className="h-5 w-5" />
              Credentials Pool
            </CardTitle>
            <CardDescription>
              {credentials?.length || 0} credentials in the system
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map(i => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            ) : credentials?.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No credentials yet. Click "Add Credential" to create one.
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Details</TableHead>
                    <TableHead>Connections</TableHead>
                    <TableHead>Assigned To</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-[100px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {credentials?.map((cred: any) => (
                    <TableRow key={cred.id}>
                      <TableCell>
                        <Badge variant={getTypeBadgeVariant(cred.type)}>
                          {getTypeLabel(cred.type)}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {cred.type === "xtream" && (
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-muted-foreground">User:</span>
                              <code className="text-xs bg-muted px-1 rounded">{cred.username}</code>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-5 w-5"
                                onClick={() => handleCopy(cred.username, `user-${cred.id}`)}
                              >
                                {copiedField === `user-${cred.id}` ? (
                                  <Check className="h-3 w-3 text-green-500" />
                                ) : (
                                  <Copy className="h-3 w-3" />
                                )}
                              </Button>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-muted-foreground">Server:</span>
                              <code className="text-xs bg-muted px-1 rounded truncate max-w-[200px]">
                                {cred.serverUrl}
                              </code>
                            </div>
                          </div>
                        )}
                        {cred.type === "m3u" && (
                          <div className="flex items-center gap-2">
                            <code className="text-xs bg-muted px-1 rounded truncate max-w-[250px]">
                              {cred.m3uUrl}
                            </code>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-5 w-5"
                              onClick={() => handleCopy(cred.m3uUrl, `m3u-${cred.id}`)}
                            >
                              {copiedField === `m3u-${cred.id}` ? (
                                <Check className="h-3 w-3 text-green-500" />
                              ) : (
                                <Copy className="h-3 w-3" />
                              )}
                            </Button>
                          </div>
                        )}
                        {cred.type === "portal" && (
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-muted-foreground">MAC:</span>
                              <code className="text-xs bg-muted px-1 rounded">{cred.macAddress}</code>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-muted-foreground">Portal:</span>
                              <code className="text-xs bg-muted px-1 rounded truncate max-w-[200px]">
                                {cred.portalUrl}
                              </code>
                            </div>
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{cred.maxConnections}</Badge>
                      </TableCell>
                      <TableCell>
                        {cred.userId ? (
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">User #{cred.userId}</span>
                          </div>
                        ) : (
                          <span className="text-muted-foreground text-sm">Unassigned</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={cred.isActive ? "default" : "secondary"}>
                          {cred.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleEdit(cred)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => {
                              if (confirm("Are you sure you want to delete this credential?")) {
                                deleteMutation.mutate({ id: cred.id });
                              }
                            }}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Create/Edit Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingCredential ? "Edit Credential" : "Add Credential"}
            </DialogTitle>
            <DialogDescription>
              {editingCredential ? "Update credential details" : "Add a new IPTV credential to the pool"}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Credential Type</Label>
              <Select
                value={formData.type}
                onValueChange={(value: "xtream" | "m3u" | "portal") => 
                  setFormData({ ...formData, type: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="xtream">Xtream Codes</SelectItem>
                  <SelectItem value="m3u">M3U URL</SelectItem>
                  <SelectItem value="portal">Portal/MAC</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.type === "xtream" && (
              <>
                <div className="space-y-2">
                  <Label>Server URL</Label>
                  <Input
                    placeholder="http://server.example.com:8080"
                    value={formData.serverUrl}
                    onChange={(e) => setFormData({ ...formData, serverUrl: e.target.value })}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Username</Label>
                    <Input
                      placeholder="username"
                      value={formData.username}
                      onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Password</Label>
                    <Input
                      placeholder="password"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    />
                  </div>
                </div>
              </>
            )}

            {formData.type === "m3u" && (
              <div className="space-y-2">
                <Label>M3U URL</Label>
                <Input
                  placeholder="http://server.example.com/playlist.m3u"
                  value={formData.m3uUrl}
                  onChange={(e) => setFormData({ ...formData, m3uUrl: e.target.value })}
                />
              </div>
            )}

            {formData.type === "portal" && (
              <>
                <div className="space-y-2">
                  <Label>Portal URL</Label>
                  <Input
                    placeholder="http://portal.example.com/c/"
                    value={formData.portalUrl}
                    onChange={(e) => setFormData({ ...formData, portalUrl: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>MAC Address</Label>
                  <Input
                    placeholder="00:1A:79:XX:XX:XX"
                    value={formData.macAddress}
                    onChange={(e) => setFormData({ ...formData, macAddress: e.target.value })}
                  />
                </div>
              </>
            )}

            <div className="space-y-2">
              <Label>Max Connections</Label>
              <Input
                type="number"
                min={1}
                max={10}
                value={formData.maxConnections}
                onChange={(e) => setFormData({ ...formData, maxConnections: parseInt(e.target.value) || 1 })}
              />
            </div>

            <div className="space-y-2">
              <Label>Notes (Optional)</Label>
              <Textarea
                placeholder="Internal notes about this credential..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Active</Label>
                <p className="text-xs text-muted-foreground">
                  Available for assignment
                </p>
              </div>
              <Switch
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSubmit} 
              disabled={createMutation.isPending || updateMutation.isPending}
            >
              {(createMutation.isPending || updateMutation.isPending) ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : editingCredential ? (
                "Update Credential"
              ) : (
                "Create Credential"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
