import { useState } from "react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { format } from "date-fns";
import { 
  FileText, 
  Search, 
  MoreHorizontal,
  CheckCircle,
  XCircle,
  Clock,
  Eye,
  Loader2,
  ExternalLink,
  Key
} from "lucide-react";

export default function AdminOrders() {
  return (
    <AppLayout isAdmin>
      <AdminOrdersContent />
    </AppLayout>
  );
}

function AdminOrdersContent() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [newStatus, setNewStatus] = useState("");
  const [adminNotes, setAdminNotes] = useState("");
  const [showCredentialsDialog, setShowCredentialsDialog] = useState(false);

  const { data: orders, isLoading, refetch } = trpc.admin.orders.list.useQuery();
  
  const updateStatusMutation = trpc.admin.orders.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Order status updated");
      setSelectedOrder(null);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const filteredOrders = orders?.filter(order => {
    const matchesSearch = 
      order.orderNumber.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === "all" || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleViewOrder = (order: any) => {
    setSelectedOrder(order);
    setNewStatus(order.status);
    setAdminNotes(order.adminNotes || "");
  };

  const handleUpdateStatus = () => {
    if (!selectedOrder) return;
    updateStatusMutation.mutate({
      id: selectedOrder.id,
      status: newStatus as any,
      adminNotes: adminNotes || undefined,
    });
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "destructive" | "outline"; className?: string }> = {
      pending: { variant: "secondary" },
      processing: { variant: "default", className: "bg-blue-500" },
      verified: { variant: "default", className: "bg-green-500" },
      paid: { variant: "default", className: "bg-green-500" },
      cancelled: { variant: "destructive" },
      refunded: { variant: "outline" },
    };
    const config = variants[status] || variants.pending;
    return (
      <Badge variant={config.variant} className={config.className}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const pendingCount = orders?.filter(o => o.status === "pending").length || 0;
  const processingCount = orders?.filter(o => o.status === "processing").length || 0;

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold">Order Management</h1>
        <p className="text-muted-foreground mt-1">
          View and manage customer orders
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="h-5 w-5" />
                  All Orders
                </CardTitle>
                <CardDescription>
                  {pendingCount > 0 && (
                    <span className="text-orange-500">{pendingCount} pending • </span>
                  )}
                  {processingCount > 0 && (
                    <span className="text-blue-500">{processingCount} processing • </span>
                  )}
                  {orders?.length || 0} total orders
                </CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue placeholder="Filter status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="verified">Verified</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                    <SelectItem value="refunded">Refunded</SelectItem>
                  </SelectContent>
                </Select>
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search orders..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3, 4, 5].map(i => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Order</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Plan</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead className="w-[50px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredOrders?.map((order) => (
                    <TableRow key={order.id}>
                      <TableCell>
                        <p className="font-medium">{order.orderNumber}</p>
                        <p className="text-xs text-muted-foreground">
                          {order.connections} connection(s)
                        </p>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        User #{order.userId}
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        Plan #{order.planId}
                      </TableCell>
                      <TableCell className="font-medium">
                        ${order.totalPrice}
                      </TableCell>
                      <TableCell>{getStatusBadge(order.status)}</TableCell>
                      <TableCell className="text-muted-foreground">
                        {format(new Date(order.createdAt), "MMM d, yyyy")}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleViewOrder(order)}>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            {order.paymentProof && (
                              <DropdownMenuItem onClick={() => window.open(order.paymentProof!, "_blank")}>
                                <ExternalLink className="h-4 w-4 mr-2" />
                                View Payment Proof
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem onClick={() => {
                              setSelectedOrder(order);
                              setShowCredentialsDialog(true);
                            }}>
                              <Key className="h-4 w-4 mr-2" />
                              Assign Credentials
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Order Details Dialog */}
      <Dialog open={!!selectedOrder && !showCredentialsDialog} onOpenChange={() => setSelectedOrder(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Order Details</DialogTitle>
            <DialogDescription>
              {selectedOrder?.orderNumber}
            </DialogDescription>
          </DialogHeader>
          {selectedOrder && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Connections</p>
                  <p className="font-medium">{selectedOrder.connections}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Amount</p>
                  <p className="font-medium">${selectedOrder.totalPrice}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Created</p>
                  <p className="font-medium">
                    {format(new Date(selectedOrder.createdAt), "MMM d, yyyy h:mm a")}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Payment Method</p>
                  <p className="font-medium">#{selectedOrder.paymentMethodId}</p>
                </div>
              </div>

              {selectedOrder.paymentProof && (
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Payment Proof</p>
                  <a 
                    href={selectedOrder.paymentProof} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-primary hover:underline text-sm flex items-center gap-1"
                  >
                    <ExternalLink className="h-3 w-3" />
                    View uploaded proof
                  </a>
                </div>
              )}

              {selectedOrder.paymentReference && (
                <div>
                  <p className="text-sm text-muted-foreground">Payment Reference</p>
                  <p className="font-medium">{selectedOrder.paymentReference}</p>
                </div>
              )}

              <div className="space-y-2">
                <Label>Update Status</Label>
                <Select value={newStatus} onValueChange={setNewStatus}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="processing">Processing</SelectItem>
                    <SelectItem value="verified">Verified</SelectItem>
                    <SelectItem value="paid">Paid</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                    <SelectItem value="refunded">Refunded</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Admin Notes</Label>
                <Textarea
                  placeholder="Add notes about this order..."
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  rows={3}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setSelectedOrder(null)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateStatus} disabled={updateStatusMutation.isPending}>
              {updateStatusMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Updating...
                </>
              ) : (
                "Update Order"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Assign Credentials Dialog */}
      <AssignCredentialsDialog
        open={showCredentialsDialog}
        onOpenChange={setShowCredentialsDialog}
        order={selectedOrder}
        onSuccess={() => {
          setShowCredentialsDialog(false);
          setSelectedOrder(null);
          refetch();
        }}
      />
    </div>
  );
}

interface AssignCredentialsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  order: any;
  onSuccess: () => void;
}

function AssignCredentialsDialog({ open, onOpenChange, order, onSuccess }: AssignCredentialsDialogProps) {
  const [credentialType, setCredentialType] = useState<"xtream" | "m3u" | "portal">("xtream");
  const [credentials, setCredentials] = useState<any[]>([]);

  const assignMutation = trpc.admin.credentials.assignToOrder.useMutation({
    onSuccess: () => {
      toast.success("Credentials assigned successfully");
      onSuccess();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleAddCredential = () => {
    const newCred = {
      type: credentialType,
      connectionNumber: credentials.length + 1,
      serverUrl: "",
      username: "",
      password: "",
      m3uUrl: "",
      portalUrl: "",
      macAddress: "",
    };
    setCredentials([...credentials, newCred]);
  };

  const handleUpdateCredential = (index: number, field: string, value: string) => {
    const updated = [...credentials];
    updated[index] = { ...updated[index], [field]: value };
    setCredentials(updated);
  };

  const handleRemoveCredential = (index: number) => {
    setCredentials(credentials.filter((_, i) => i !== index));
  };

  const handleAssign = () => {
    if (!order || credentials.length === 0) return;
    assignMutation.mutate({
      orderId: order.id,
      credentials: credentials.map(c => ({
        type: c.type,
        connectionNumber: c.connectionNumber,
        serverUrl: c.serverUrl || undefined,
        username: c.username || undefined,
        password: c.password || undefined,
        m3uUrl: c.m3uUrl || undefined,
        portalUrl: c.portalUrl || undefined,
        macAddress: c.macAddress || undefined,
      })),
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Assign Credentials</DialogTitle>
          <DialogDescription>
            Assign IPTV credentials to order {order?.orderNumber}
            ({order?.connections} connection(s) required)
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Select value={credentialType} onValueChange={(v: any) => setCredentialType(v)}>
              <SelectTrigger className="w-[150px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="xtream">Xtream</SelectItem>
                <SelectItem value="m3u">M3U</SelectItem>
                <SelectItem value="portal">Portal</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={handleAddCredential}>
              Add Credential
            </Button>
          </div>

          {credentials.map((cred, index) => (
            <Card key={index}>
              <CardHeader className="py-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm">
                    Connection #{cred.connectionNumber} - {cred.type.toUpperCase()}
                  </CardTitle>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => handleRemoveCredential(index)}
                  >
                    <XCircle className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="py-3 space-y-3">
                {cred.type === "xtream" && (
                  <>
                    <div className="grid grid-cols-3 gap-2">
                      <Input
                        placeholder="Server URL"
                        value={cred.serverUrl}
                        onChange={(e) => handleUpdateCredential(index, "serverUrl", e.target.value)}
                      />
                      <Input
                        placeholder="Username"
                        value={cred.username}
                        onChange={(e) => handleUpdateCredential(index, "username", e.target.value)}
                      />
                      <Input
                        placeholder="Password"
                        value={cred.password}
                        onChange={(e) => handleUpdateCredential(index, "password", e.target.value)}
                      />
                    </div>
                  </>
                )}
                {cred.type === "m3u" && (
                  <Input
                    placeholder="M3U URL"
                    value={cred.m3uUrl}
                    onChange={(e) => handleUpdateCredential(index, "m3uUrl", e.target.value)}
                  />
                )}
                {cred.type === "portal" && (
                  <div className="grid grid-cols-2 gap-2">
                    <Input
                      placeholder="Portal URL"
                      value={cred.portalUrl}
                      onChange={(e) => handleUpdateCredential(index, "portalUrl", e.target.value)}
                    />
                    <Input
                      placeholder="MAC Address"
                      value={cred.macAddress}
                      onChange={(e) => handleUpdateCredential(index, "macAddress", e.target.value)}
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          ))}

          {credentials.length === 0 && (
            <div className="text-center py-8 text-muted-foreground">
              Add credentials for each connection
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleAssign} 
            disabled={credentials.length === 0 || assignMutation.isPending}
          >
            {assignMutation.isPending ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Assigning...
              </>
            ) : (
              "Assign & Mark as Paid"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
