import { useState } from "react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { 
  Settings, 
  Key,
  Mail,
  Loader2,
  Save
} from "lucide-react";

export default function AdminSettings() {
  return (
    <AppLayout isAdmin>
      <AdminSettingsContent />
    </AppLayout>
  );
}

function AdminSettingsContent() {
  const [nowpaymentsKey, setNowpaymentsKey] = useState("");
  const [nowpaymentsIpnSecret, setNowpaymentsIpnSecret] = useState("");
  const [brevoApiKey, setBrevoApiKey] = useState("");
  const [brevoSenderEmail, setBrevoSenderEmail] = useState("");
  const [brevoSenderName, setBrevoSenderName] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const handleSaveNowPayments = async () => {
    setIsSaving(true);
    try {
      // In a real app, this would save to the database
      toast.success("NOWPayments settings saved! Please update environment variables.");
    } catch (error) {
      toast.error("Failed to save settings");
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveBrevo = async () => {
    setIsSaving(true);
    try {
      // In a real app, this would save to the database
      toast.success("Brevo settings saved! Please update environment variables.");
    } catch (error) {
      toast.error("Failed to save settings");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-muted-foreground mt-1">
          Configure platform settings and integrations
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Tabs defaultValue="payments" className="w-full">
          <TabsList>
            <TabsTrigger value="payments" className="gap-2">
              <Key className="h-4 w-4" />
              Payment Gateway
            </TabsTrigger>
            <TabsTrigger value="email" className="gap-2">
              <Mail className="h-4 w-4" />
              Email (Brevo)
            </TabsTrigger>
            <TabsTrigger value="general" className="gap-2">
              <Settings className="h-4 w-4" />
              General
            </TabsTrigger>
          </TabsList>

          <TabsContent value="payments" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5" />
                  NOWPayments Configuration
                </CardTitle>
                <CardDescription>
                  Configure your NOWPayments API credentials for cryptocurrency payments
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>API Key</Label>
                  <Input
                    type="password"
                    placeholder="Your NOWPayments API key"
                    value={nowpaymentsKey}
                    onChange={(e) => setNowpaymentsKey(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Get your API key from the NOWPayments dashboard
                  </p>
                </div>

                <div className="space-y-2">
                  <Label>IPN Secret</Label>
                  <Input
                    type="password"
                    placeholder="Your IPN callback secret"
                    value={nowpaymentsIpnSecret}
                    onChange={(e) => setNowpaymentsIpnSecret(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    Used to verify webhook callbacks from NOWPayments
                  </p>
                </div>

                <div className="pt-4">
                  <Button onClick={handleSaveNowPayments} disabled={isSaving}>
                    {isSaving ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Save Settings
                      </>
                    )}
                  </Button>
                </div>

                <div className="mt-6 p-4 rounded-lg bg-muted/50">
                  <h4 className="font-medium mb-2">Environment Variables Required</h4>
                  <p className="text-sm text-muted-foreground mb-2">
                    Add these to your environment configuration:
                  </p>
                  <code className="text-xs bg-background p-2 rounded block">
                    NOWPAYMENTS_API_KEY=your_api_key<br />
                    NOWPAYMENTS_IPN_SECRET=your_ipn_secret
                  </code>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="email" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Mail className="h-5 w-5" />
                  Brevo (Sendinblue) Configuration
                </CardTitle>
                <CardDescription>
                  Configure your Brevo SMTP settings for sending emails
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>API Key</Label>
                  <Input
                    type="password"
                    placeholder="Your Brevo API key"
                    value={brevoApiKey}
                    onChange={(e) => setBrevoApiKey(e.target.value)}
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Sender Email</Label>
                    <Input
                      type="email"
                      placeholder="noreply@yourdomain.com"
                      value={brevoSenderEmail}
                      onChange={(e) => setBrevoSenderEmail(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Sender Name</Label>
                    <Input
                      placeholder="Your Company Name"
                      value={brevoSenderName}
                      onChange={(e) => setBrevoSenderName(e.target.value)}
                    />
                  </div>
                </div>

                <div className="pt-4">
                  <Button onClick={handleSaveBrevo} disabled={isSaving}>
                    {isSaving ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Save Settings
                      </>
                    )}
                  </Button>
                </div>

                <div className="mt-6 p-4 rounded-lg bg-muted/50">
                  <h4 className="font-medium mb-2">Environment Variables Required</h4>
                  <p className="text-sm text-muted-foreground mb-2">
                    Add these to your environment configuration:
                  </p>
                  <code className="text-xs bg-background p-2 rounded block">
                    BREVO_API_KEY=your_api_key<br />
                    BREVO_SENDER_EMAIL=noreply@yourdomain.com<br />
                    BREVO_SENDER_NAME=Your Company
                  </code>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="general" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5" />
                  General Settings
                </CardTitle>
                <CardDescription>
                  Configure general platform settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Maintenance Mode</Label>
                    <p className="text-sm text-muted-foreground">
                      Disable access to the platform for non-admin users
                    </p>
                  </div>
                  <Switch />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>New Registrations</Label>
                    <p className="text-sm text-muted-foreground">
                      Allow new users to register
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Email Verification Required</Label>
                    <p className="text-sm text-muted-foreground">
                      Require email verification before login
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Auto-assign Credentials</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically assign credentials when payment is verified
                    </p>
                  </div>
                  <Switch />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
}
