import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Users, 
  ShoppingCart, 
  DollarSign, 
  Clock,
  TrendingUp,
  ArrowUpRight,
  ArrowDownRight
} from "lucide-react";

export default function AdminDashboard() {
  return (
    <AppLayout isAdmin>
      <AdminDashboardContent />
    </AppLayout>
  );
}

function AdminDashboardContent() {
  const { data: stats, isLoading } = trpc.admin.stats.useQuery();

  const statCards = [
    {
      title: "Total Users",
      value: stats?.userCount || 0,
      icon: Users,
      description: "Registered users",
      trend: "+12%",
      trendUp: true,
    },
    {
      title: "Total Orders",
      value: stats?.orderCount || 0,
      icon: ShoppingCart,
      description: "All time orders",
      trend: "+8%",
      trendUp: true,
    },
    {
      title: "Total Revenue",
      value: `$${Number(stats?.totalRevenue || 0).toFixed(2)}`,
      icon: DollarSign,
      description: "Lifetime earnings",
      trend: "+23%",
      trendUp: true,
    },
    {
      title: "Pending Orders",
      value: stats?.pendingOrderCount || 0,
      icon: Clock,
      description: "Awaiting verification",
      trend: stats?.pendingOrderCount && stats.pendingOrderCount > 0 ? "Action needed" : "All clear",
      trendUp: false,
    },
  ];

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground mt-1">
          Overview of your IPTV SaaS platform
        </p>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * index }}
          >
            <Card>
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {stat.title}
                </CardTitle>
                <stat.icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <Skeleton className="h-8 w-24" />
                ) : (
                  <>
                    <div className="text-2xl font-bold">{stat.value}</div>
                    <div className="flex items-center gap-1 mt-1">
                      {stat.trendUp ? (
                        <ArrowUpRight className="h-3 w-3 text-green-500" />
                      ) : stat.trend === "Action needed" ? (
                        <Clock className="h-3 w-3 text-orange-500" />
                      ) : (
                        <TrendingUp className="h-3 w-3 text-green-500" />
                      )}
                      <span className={`text-xs ${
                        stat.trend === "Action needed" 
                          ? "text-orange-500" 
                          : "text-green-500"
                      }`}>
                        {stat.trend}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {stat.description}
                    </p>
                  </>
                )}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common administrative tasks</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-4">
              <QuickActionCard
                title="Pending Orders"
                description="Review and verify payments"
                count={stats?.pendingOrderCount || 0}
                href="/admin/orders"
              />
              <QuickActionCard
                title="Manage Plans"
                description="Create and edit subscription plans"
                href="/admin/plans"
              />
              <QuickActionCard
                title="Payment Methods"
                description="Configure payment options"
                href="/admin/payments"
              />
              <QuickActionCard
                title="Support Chat"
                description="Respond to customer inquiries"
                href="/admin/chat"
              />
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}

interface QuickActionCardProps {
  title: string;
  description: string;
  count?: number;
  href: string;
}

function QuickActionCard({ title, description, count, href }: QuickActionCardProps) {
  return (
    <a
      href={href}
      className="block p-4 rounded-lg border hover:bg-muted/50 transition-colors"
    >
      <div className="flex items-center justify-between mb-2">
        <h4 className="font-medium">{title}</h4>
        {count !== undefined && count > 0 && (
          <span className="px-2 py-1 text-xs font-medium bg-primary text-primary-foreground rounded-full">
            {count}
          </span>
        )}
      </div>
      <p className="text-sm text-muted-foreground">{description}</p>
    </a>
  );
}
