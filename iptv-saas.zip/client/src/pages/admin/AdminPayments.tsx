import { useState } from "react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { 
  CreditCard, 
  Plus,
  Pencil,
  Trash2,
  Loader2,
  Bitcoin,
  Link,
  FileText
} from "lucide-react";

export default function AdminPayments() {
  return (
    <AppLayout isAdmin>
      <AdminPaymentsContent />
    </AppLayout>
  );
}

function AdminPaymentsContent() {
  const [showDialog, setShowDialog] = useState(false);
  const [showPlanLinkDialog, setShowPlanLinkDialog] = useState(false);
  const [editingMethod, setEditingMethod] = useState<any>(null);
  const [selectedMethod, setSelectedMethod] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: "",
    type: "manual_custom" as "crypto" | "manual_card" | "manual_paypal" | "manual_custom",
    instructions: "",
    paymentLink: "",
    hasLink: false,
    iconUrl: "",
    isActive: true,
    sortOrder: 0,
  });

  const { data: methods, isLoading, refetch } = trpc.admin.paymentMethods.list.useQuery();
  const { data: plans } = trpc.admin.plans.list.useQuery();
  
  const createMutation = trpc.admin.paymentMethods.create.useMutation({
    onSuccess: () => {
      toast.success("Payment method created successfully");
      setShowDialog(false);
      resetForm();
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const updateMutation = trpc.admin.paymentMethods.update.useMutation({
    onSuccess: () => {
      toast.success("Payment method updated successfully");
      setShowDialog(false);
      resetForm();
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const deleteMutation = trpc.admin.paymentMethods.delete.useMutation({
    onSuccess: () => {
      toast.success("Payment method deleted successfully");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const resetForm = () => {
    setEditingMethod(null);
    setFormData({
      name: "",
      type: "manual_custom",
      instructions: "",
      paymentLink: "",
      hasLink: false,
      iconUrl: "",
      isActive: true,
      sortOrder: 0,
    });
  };

  const handleEdit = (method: any) => {
    setEditingMethod(method);
    setFormData({
      name: method.name,
      type: method.type,
      instructions: method.instructions || "",
      paymentLink: method.paymentLink || "",
      hasLink: method.hasLink,
      iconUrl: method.iconUrl || "",
      isActive: method.isActive,
      sortOrder: method.sortOrder,
    });
    setShowDialog(true);
  };

  const handleSubmit = () => {
    if (editingMethod) {
      updateMutation.mutate({
        id: editingMethod.id,
        name: formData.name,
        instructions: formData.instructions || undefined,
        paymentLink: formData.paymentLink || undefined,
        hasLink: formData.hasLink,
        iconUrl: formData.iconUrl || undefined,
        isActive: formData.isActive,
        sortOrder: formData.sortOrder,
      });
    } else {
      createMutation.mutate({
        name: formData.name,
        type: formData.type,
        instructions: formData.instructions || undefined,
        paymentLink: formData.paymentLink || undefined,
        hasLink: formData.hasLink,
        iconUrl: formData.iconUrl || undefined,
        isActive: formData.isActive,
        sortOrder: formData.sortOrder,
      });
    }
  };

  const handleDelete = (id: number) => {
    if (confirm("Are you sure you want to delete this payment method?")) {
      deleteMutation.mutate({ id });
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "crypto":
        return <Bitcoin className="h-4 w-4" />;
      case "manual_card":
        return <CreditCard className="h-4 w-4" />;
      case "manual_paypal":
        return <CreditCard className="h-4 w-4" />;
      default:
        return <FileText className="h-4 w-4" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "crypto":
        return "Cryptocurrency";
      case "manual_card":
        return "Manual Card";
      case "manual_paypal":
        return "Manual PayPal";
      default:
        return "Custom";
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold">Payment Methods</h1>
          <p className="text-muted-foreground mt-1">
            Configure payment options for customers
          </p>
        </div>
        <Button onClick={() => { resetForm(); setShowDialog(true); }}>
          <Plus className="h-4 w-4 mr-2" />
          Add Method
        </Button>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5" />
              Payment Methods
            </CardTitle>
            <CardDescription>
              {methods?.length || 0} payment methods configured
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-4">
                {[1, 2, 3].map(i => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : methods?.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No payment methods configured. Click "Add Method" to create one.
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Has Link</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-[150px]"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {methods?.map((method) => (
                    <TableRow key={method.id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {getTypeIcon(method.type)}
                          <span className="font-medium">{method.name}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{getTypeLabel(method.type)}</Badge>
                      </TableCell>
                      <TableCell>
                        {method.hasLink ? (
                          <Badge variant="secondary">
                            <Link className="h-3 w-3 mr-1" />
                            Yes
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground">No</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={method.isActive ? "default" : "secondary"}>
                          {method.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleEdit(method)}
                          >
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => {
                              setSelectedMethod(method);
                              setShowPlanLinkDialog(true);
                            }}
                          >
                            <Link className="h-4 w-4" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon"
                            onClick={() => handleDelete(method.id)}
                            disabled={method.type === "crypto"}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Payment Method Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{editingMethod ? "Edit Payment Method" : "Add Payment Method"}</DialogTitle>
            <DialogDescription>
              {editingMethod ? "Update payment method details" : "Configure a new payment option"}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Method Name</Label>
              <Input
                placeholder="e.g., Bank Transfer, PayPal, Bitcoin"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>

            {!editingMethod && (
              <div className="space-y-2">
                <Label>Type</Label>
                <Select 
                  value={formData.type} 
                  onValueChange={(v: any) => setFormData({ ...formData, type: v })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="crypto">Cryptocurrency (NOWPayments)</SelectItem>
                    <SelectItem value="manual_card">Manual Card Payment</SelectItem>
                    <SelectItem value="manual_paypal">Manual PayPal</SelectItem>
                    <SelectItem value="manual_custom">Custom Manual Method</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-2">
              <Label>Instructions</Label>
              <Textarea
                placeholder="Payment instructions for customers..."
                value={formData.instructions}
                onChange={(e) => setFormData({ ...formData, instructions: e.target.value })}
                rows={4}
              />
              <p className="text-xs text-muted-foreground">
                These instructions will be shown to customers after they create an order
              </p>
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Include Payment Link</Label>
                <p className="text-xs text-muted-foreground">
                  Add a clickable link for customers
                </p>
              </div>
              <Switch
                checked={formData.hasLink}
                onCheckedChange={(checked) => setFormData({ ...formData, hasLink: checked })}
              />
            </div>

            {formData.hasLink && (
              <div className="space-y-2">
                <Label>Payment Link URL</Label>
                <Input
                  placeholder="https://paypal.me/yourname"
                  value={formData.paymentLink}
                  onChange={(e) => setFormData({ ...formData, paymentLink: e.target.value })}
                />
              </div>
            )}

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Active</Label>
                <p className="text-xs text-muted-foreground">
                  Show this payment method to customers
                </p>
              </div>
              <Switch
                checked={formData.isActive}
                onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handleSubmit} disabled={isPending || !formData.name}>
              {isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : editingMethod ? (
                "Update Method"
              ) : (
                "Create Method"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Plan-Specific Links Dialog */}
      <PlanLinksDialog
        open={showPlanLinkDialog}
        onOpenChange={setShowPlanLinkDialog}
        method={selectedMethod}
        plans={plans || []}
      />
    </div>
  );
}

interface PlanLinksDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  method: any;
  plans: any[];
}

function PlanLinksDialog({ open, onOpenChange, method, plans }: PlanLinksDialogProps) {
  const [planLinks, setPlanLinks] = useState<Record<number, { link: string; instructions: string }>>({});

  const setPlanLinkMutation = trpc.admin.paymentMethods.setPlanLink.useMutation({
    onSuccess: () => {
      toast.success("Plan link saved");
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleSavePlanLink = (planId: number) => {
    if (!method) return;
    const data = planLinks[planId] || { link: "", instructions: "" };
    setPlanLinkMutation.mutate({
      planId,
      paymentMethodId: method.id,
      customLink: data.link || undefined,
      customInstructions: data.instructions || undefined,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Plan-Specific Payment Links</DialogTitle>
          <DialogDescription>
            Configure different payment links for each plan with {method?.name}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          {plans.map((plan) => (
            <Card key={plan.id}>
              <CardHeader className="py-3">
                <CardTitle className="text-sm">{plan.name}</CardTitle>
              </CardHeader>
              <CardContent className="py-3 space-y-3">
                <div className="space-y-2">
                  <Label className="text-xs">Custom Payment Link</Label>
                  <Input
                    placeholder="Leave empty to use default"
                    value={planLinks[plan.id]?.link || ""}
                    onChange={(e) => setPlanLinks({
                      ...planLinks,
                      [plan.id]: { ...planLinks[plan.id], link: e.target.value }
                    })}
                  />
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Custom Instructions</Label>
                  <Textarea
                    placeholder="Leave empty to use default"
                    value={planLinks[plan.id]?.instructions || ""}
                    onChange={(e) => setPlanLinks({
                      ...planLinks,
                      [plan.id]: { ...planLinks[plan.id], instructions: e.target.value }
                    })}
                    rows={2}
                  />
                </div>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => handleSavePlanLink(plan.id)}
                  disabled={setPlanLinkMutation.isPending}
                >
                  {setPlanLinkMutation.isPending ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    "Save"
                  )}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
