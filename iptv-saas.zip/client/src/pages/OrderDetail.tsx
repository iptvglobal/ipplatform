import { useState } from "react";
import { motion } from "framer-motion";
import { trpc } from "@/lib/trpc";
import AppLayout from "@/components/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { useLocation, useParams } from "wouter";
import { format } from "date-fns";
import { 
  ArrowLeft, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  ExternalLink,
  Copy,
  Upload,
  Key,
  CreditCard,
  Loader2
} from "lucide-react";

export default function OrderDetail() {
  return (
    <AppLayout>
      <OrderDetailContent />
    </AppLayout>
  );
}

function OrderDetailContent() {
  const [, setLocation] = useLocation();
  const params = useParams<{ id: string }>();
  const orderId = parseInt(params.id || "0");
  
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [proofUrl, setProofUrl] = useState("");
  const [reference, setReference] = useState("");

  const { data: order, isLoading, refetch } = trpc.orders.get.useQuery(
    { id: orderId },
    { enabled: orderId > 0 }
  );

  const uploadProofMutation = trpc.orders.uploadProof.useMutation({
    onSuccess: () => {
      toast.success("Payment proof uploaded successfully!");
      setShowUploadDialog(false);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: "default" | "secondary" | "destructive" | "outline"; icon: React.ReactNode; className?: string }> = {
      pending: { variant: "secondary", icon: <Clock className="w-3 h-3" /> },
      processing: { variant: "default", icon: <Clock className="w-3 h-3" />, className: "bg-blue-500" },
      verified: { variant: "default", icon: <CheckCircle className="w-3 h-3" />, className: "bg-green-500" },
      paid: { variant: "default", icon: <CheckCircle className="w-3 h-3" />, className: "bg-green-500" },
      cancelled: { variant: "destructive", icon: <AlertCircle className="w-3 h-3" /> },
      refunded: { variant: "outline", icon: <AlertCircle className="w-3 h-3" /> },
    };
    const config = variants[status] || variants.pending;
    return (
      <Badge variant={config.variant} className={`gap-1 ${config.className || ""}`}>
        {config.icon}
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast.success("Copied to clipboard!");
  };

  const handleUploadProof = () => {
    if (!proofUrl) {
      toast.error("Please enter a proof URL");
      return;
    }
    uploadProofMutation.mutate({
      orderId,
      proofUrl,
      reference: reference || undefined,
    });
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <Card>
          <CardContent className="p-6">
            <div className="space-y-4">
              <Skeleton className="h-6 w-32" />
              <Skeleton className="h-4 w-64" />
              <Skeleton className="h-4 w-48" />
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="text-center py-12">
        <h2 className="text-xl font-semibold mb-2">Order not found</h2>
        <Button onClick={() => setLocation("/dashboard/orders")}>
          Back to Orders
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center gap-4"
      >
        <Button variant="ghost" size="icon" onClick={() => setLocation("/dashboard/orders")}>
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-bold">{order.orderNumber}</h1>
            {getStatusBadge(order.status)}
          </div>
          <p className="text-muted-foreground">
            Created {format(new Date(order.createdAt), "MMMM d, yyyy 'at' h:mm a")}
          </p>
        </div>
      </motion.div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Order Details */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <Card>
            <CardHeader>
              <CardTitle>Order Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Plan</p>
                  <p className="font-medium">{order.plan?.name || "N/A"}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Connections</p>
                  <p className="font-medium">{order.connections}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Duration</p>
                  <p className="font-medium">{order.plan?.durationDays || 0} days</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total Price</p>
                  <p className="font-medium text-lg">${order.totalPrice}</p>
                </div>
              </div>

              {order.paymentMethod && (
                <div className="pt-4 border-t">
                  <p className="text-sm text-muted-foreground mb-2">Payment Method</p>
                  <div className="flex items-center gap-2">
                    <CreditCard className="h-4 w-4" />
                    <span className="font-medium">{order.paymentMethod.name}</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        {/* Payment Instructions */}
        {order.status === "pending" && order.paymentMethod && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle>Payment Instructions</CardTitle>
                <CardDescription>
                  Complete your payment using the instructions below
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {order.cryptoPaymentUrl ? (
                  <div className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      Click the button below to complete your cryptocurrency payment
                    </p>
                    <Button 
                      className="w-full"
                      onClick={() => window.open(order.cryptoPaymentUrl!, "_blank")}
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Pay with Crypto
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {order.paymentMethod.instructions && (
                      <div className="p-4 rounded-lg bg-muted/50">
                        <p className="text-sm whitespace-pre-wrap">
                          {order.paymentMethod.instructions}
                        </p>
                      </div>
                    )}

                    {order.paymentMethod.hasLink && order.paymentMethod.paymentLink && (
                      <Button 
                        variant="outline"
                        className="w-full"
                        onClick={() => window.open(order.paymentMethod!.paymentLink!, "_blank")}
                      >
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Open Payment Link
                      </Button>
                    )}

                    <div className="pt-4 border-t">
                      <p className="text-sm text-muted-foreground mb-2">
                        After completing your payment, upload proof of payment
                      </p>
                      <Button onClick={() => setShowUploadDialog(true)}>
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Payment Proof
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Processing Status */}
        {order.status === "processing" && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-blue-500" />
                  Payment Under Review
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Your payment proof has been submitted and is being reviewed by our team. 
                  You will receive an email notification once your payment is verified.
                </p>
                {order.paymentProof && (
                  <div className="mt-4 p-4 rounded-lg bg-muted/50">
                    <p className="text-sm text-muted-foreground mb-1">Submitted Proof</p>
                    <a 
                      href={order.paymentProof} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary hover:underline text-sm"
                    >
                      View uploaded proof
                    </a>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Credentials */}
        {(order.status === "paid" || order.status === "verified") && order.credentials && order.credentials.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="h-5 w-5 text-green-500" />
                  Your IPTV Credentials
                </CardTitle>
                <CardDescription>
                  Use these credentials to access your IPTV service
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-2">
                  {order.credentials.map((cred) => (
                    <Card key={cred.id} className="bg-muted/30">
                      <CardHeader className="pb-2">
                        <CardTitle className="text-base flex items-center justify-between">
                          <span className="capitalize">{cred.type} Credentials</span>
                          <Badge variant="outline">Connection #{cred.connectionNumber}</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        {cred.type === "xtream" && (
                          <>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-muted-foreground">Server URL</span>
                              <div className="flex items-center gap-2">
                                <code className="text-sm bg-background px-2 py-1 rounded">
                                  {cred.serverUrl}
                                </code>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-8 w-8"
                                  onClick={() => copyToClipboard(cred.serverUrl || "")}
                                >
                                  <Copy className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-muted-foreground">Username</span>
                              <div className="flex items-center gap-2">
                                <code className="text-sm bg-background px-2 py-1 rounded">
                                  {cred.username}
                                </code>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-8 w-8"
                                  onClick={() => copyToClipboard(cred.username || "")}
                                >
                                  <Copy className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-muted-foreground">Password</span>
                              <div className="flex items-center gap-2">
                                <code className="text-sm bg-background px-2 py-1 rounded">
                                  {cred.password}
                                </code>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-8 w-8"
                                  onClick={() => copyToClipboard(cred.password || "")}
                                >
                                  <Copy className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          </>
                        )}

                        {cred.type === "m3u" && (
                          <div className="space-y-2">
                            <span className="text-sm text-muted-foreground">M3U URL</span>
                            <div className="flex items-center gap-2">
                              <code className="text-xs bg-background px-2 py-1 rounded break-all flex-1">
                                {cred.m3uUrl}
                              </code>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="h-8 w-8 shrink-0"
                                onClick={() => copyToClipboard(cred.m3uUrl || "")}
                              >
                                <Copy className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        )}

                        {cred.type === "portal" && (
                          <>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-muted-foreground">Portal URL</span>
                              <div className="flex items-center gap-2">
                                <code className="text-sm bg-background px-2 py-1 rounded">
                                  {cred.portalUrl}
                                </code>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-8 w-8"
                                  onClick={() => copyToClipboard(cred.portalUrl || "")}
                                >
                                  <Copy className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-muted-foreground">MAC Address</span>
                              <div className="flex items-center gap-2">
                                <code className="text-sm bg-background px-2 py-1 rounded">
                                  {cred.macAddress}
                                </code>
                                <Button 
                                  variant="ghost" 
                                  size="icon" 
                                  className="h-8 w-8"
                                  onClick={() => copyToClipboard(cred.macAddress || "")}
                                >
                                  <Copy className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          </>
                        )}

                        {cred.expiresAt && (
                          <div className="pt-2 border-t">
                            <p className="text-xs text-muted-foreground">
                              Expires: {format(new Date(cred.expiresAt), "MMMM d, yyyy")}
                            </p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>

      {/* Upload Proof Dialog */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Upload Payment Proof</DialogTitle>
            <DialogDescription>
              Provide a link to your payment proof (screenshot, transaction ID, etc.)
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="proof-url">Proof URL</Label>
              <Input
                id="proof-url"
                placeholder="https://example.com/payment-proof.png"
                value={proofUrl}
                onChange={(e) => setProofUrl(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Upload your proof to an image hosting service and paste the URL here
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="reference">Payment Reference (optional)</Label>
              <Input
                id="reference"
                placeholder="Transaction ID or reference number"
                value={reference}
                onChange={(e) => setReference(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowUploadDialog(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleUploadProof}
              disabled={uploadProofMutation.isPending}
            >
              {uploadProofMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Uploading...
                </>
              ) : (
                "Submit Proof"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
