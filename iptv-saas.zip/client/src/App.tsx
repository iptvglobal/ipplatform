import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch, Redirect } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { useAuth } from "@/_core/hooks/useAuth";

// Auth pages
import Login from "./pages/Login";
import VerifyEmail from "./pages/VerifyEmail";
import ResetPassword from "./pages/ResetPassword";

// User pages
import Dashboard from "./pages/Dashboard";
import Plans from "./pages/Plans";
import Orders from "./pages/Orders";
import OrderDetail from "./pages/OrderDetail";
import Credentials from "./pages/Credentials";
import Support from "./pages/Support";

// Admin pages
import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminOrders from "./pages/admin/AdminOrders";
import AdminPlans from "./pages/admin/AdminPlans";
import AdminPayments from "./pages/admin/AdminPayments";
import AdminChat from "./pages/admin/AdminChat";
import AdminEmails from "./pages/admin/AdminEmails";
import AdminSettings from "./pages/admin/AdminSettings";
import AdminCredentials from "./pages/admin/AdminCredentials";
import AdminLogs from "./pages/admin/AdminLogs";

// Protected route wrapper
function ProtectedRoute({ component: Component, adminOnly = false }: { component: React.ComponentType; adminOnly?: boolean }) {
  const { user, loading, isAuthenticated } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Redirect to="/" />;
  }

  if (adminOnly && user?.role !== "admin") {
    return <Redirect to="/dashboard" />;
  }

  return <Component />;
}

function Router() {
  const { isAuthenticated, loading, user } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <Switch>
      {/* Public auth routes */}
      <Route path="/">
        {isAuthenticated ? (
          user?.role === "admin" ? <Redirect to="/admin" /> : <Redirect to="/dashboard" />
        ) : (
          <Login />
        )}
      </Route>
      <Route path="/verify-email" component={VerifyEmail} />
      <Route path="/reset-password" component={ResetPassword} />

      {/* User routes */}
      <Route path="/dashboard">
        <ProtectedRoute component={Dashboard} />
      </Route>
      <Route path="/dashboard/plans">
        <ProtectedRoute component={Plans} />
      </Route>
      <Route path="/dashboard/orders">
        <ProtectedRoute component={Orders} />
      </Route>
      <Route path="/dashboard/orders/:id">
        <ProtectedRoute component={OrderDetail} />
      </Route>
      <Route path="/dashboard/credentials">
        <ProtectedRoute component={Credentials} />
      </Route>
      <Route path="/dashboard/support">
        <ProtectedRoute component={Support} />
      </Route>

      {/* Admin routes */}
      <Route path="/admin">
        <ProtectedRoute component={AdminDashboard} adminOnly />
      </Route>
      <Route path="/admin/users">
        <ProtectedRoute component={AdminUsers} adminOnly />
      </Route>
      <Route path="/admin/orders">
        <ProtectedRoute component={AdminOrders} adminOnly />
      </Route>
      <Route path="/admin/plans">
        <ProtectedRoute component={AdminPlans} adminOnly />
      </Route>
      <Route path="/admin/payments">
        <ProtectedRoute component={AdminPayments} adminOnly />
      </Route>
      <Route path="/admin/chat">
        <ProtectedRoute component={AdminChat} adminOnly />
      </Route>
      <Route path="/admin/emails">
        <ProtectedRoute component={AdminEmails} adminOnly />
      </Route>
      <Route path="/admin/settings">
        <ProtectedRoute component={AdminSettings} adminOnly />
      </Route>
      <Route path="/admin/credentials">
        <ProtectedRoute component={AdminCredentials} adminOnly />
      </Route>
      <Route path="/admin/logs">
        <ProtectedRoute component={AdminLogs} adminOnly />
      </Route>

      {/* 404 */}
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
