import * as db from "./db";
import crypto from "crypto";

interface NOWPaymentsConfig {
  apiKey: string;
  ipnSecret: string;
  sandboxMode?: boolean;
}

interface CreateInvoiceParams {
  priceAmount: number;
  priceCurrency: string;
  orderId: string;
  orderDescription: string;
  successUrl?: string;
  cancelUrl?: string;
}

interface InvoiceResponse {
  id: string;
  token_id: string;
  order_id: string;
  order_description: string;
  price_amount: string;
  price_currency: string;
  pay_currency: string | null;
  ipn_callback_url: string | null;
  invoice_url: string;
  success_url: string | null;
  cancel_url: string | null;
  created_at: string;
  updated_at: string;
}

interface PaymentStatus {
  payment_id: number;
  payment_status: string;
  pay_address: string;
  price_amount: number;
  price_currency: string;
  pay_amount: number;
  pay_currency: string;
  order_id: string;
  order_description: string;
  purchase_id: string;
  created_at: string;
  updated_at: string;
  outcome_amount: number;
  outcome_currency: string;
}

interface IPNPayload {
  payment_id: number;
  payment_status: string;
  pay_address: string;
  price_amount: number;
  price_currency: string;
  pay_amount: number;
  pay_currency: string;
  order_id: string;
  order_description: string;
  purchase_id: string;
  created_at: string;
  updated_at: string;
  outcome_amount: number;
  outcome_currency: string;
  actually_paid: number;
  actually_paid_at_fiat: number;
}

const BASE_URL = "https://api.nowpayments.io/v1";

async function getConfig(): Promise<NOWPaymentsConfig | null> {
  const apiKeySetting = await db.getSetting("nowpayments_api_key");
  const ipnSecretSetting = await db.getSetting("nowpayments_ipn_secret");
  
  if (!apiKeySetting?.value) {
    console.warn("[NOWPayments] API key not configured");
    return null;
  }

  return {
    apiKey: apiKeySetting.value,
    ipnSecret: ipnSecretSetting?.value || "",
    sandboxMode: false,
  };
}

export async function createInvoice(params: CreateInvoiceParams): Promise<InvoiceResponse | null> {
  const config = await getConfig();
  if (!config) return null;

  try {
    const response = await fetch(`${BASE_URL}/invoice`, {
      method: "POST",
      headers: {
        "x-api-key": config.apiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        price_amount: params.priceAmount,
        price_currency: params.priceCurrency,
        order_id: params.orderId,
        order_description: params.orderDescription,
        success_url: params.successUrl,
        cancel_url: params.cancelUrl,
        is_fee_paid_by_user: false,
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("[NOWPayments] Failed to create invoice:", error);
      return null;
    }

    const data = await response.json();
    console.log("[NOWPayments] Invoice created:", data.id);
    return data;
  } catch (error) {
    console.error("[NOWPayments] Error creating invoice:", error);
    return null;
  }
}

export async function getPaymentStatus(paymentId: string): Promise<PaymentStatus | null> {
  const config = await getConfig();
  if (!config) return null;

  try {
    const response = await fetch(`${BASE_URL}/payment/${paymentId}`, {
      headers: {
        "x-api-key": config.apiKey,
      },
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("[NOWPayments] Failed to get payment status:", error);
      return null;
    }

    return await response.json();
  } catch (error) {
    console.error("[NOWPayments] Error getting payment status:", error);
    return null;
  }
}

export async function getAvailableCurrencies(): Promise<string[]> {
  const config = await getConfig();
  if (!config) return [];

  try {
    const response = await fetch(`${BASE_URL}/currencies`, {
      headers: {
        "x-api-key": config.apiKey,
      },
    });

    if (!response.ok) {
      return [];
    }

    const data = await response.json();
    return data.currencies || [];
  } catch (error) {
    console.error("[NOWPayments] Error getting currencies:", error);
    return [];
  }
}

export async function getMinimumPaymentAmount(currency: string): Promise<number | null> {
  const config = await getConfig();
  if (!config) return null;

  try {
    const response = await fetch(`${BASE_URL}/min-amount?currency_from=${currency}`, {
      headers: {
        "x-api-key": config.apiKey,
      },
    });

    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    return data.min_amount || null;
  } catch (error) {
    console.error("[NOWPayments] Error getting minimum amount:", error);
    return null;
  }
}

export function verifyIPNSignature(payload: string, signature: string, ipnSecret: string): boolean {
  if (!ipnSecret) {
    console.warn("[NOWPayments] IPN secret not configured, skipping verification");
    return true;
  }

  try {
    // Sort the payload keys and create the signature
    const payloadObj = JSON.parse(payload);
    const sortedPayload = Object.keys(payloadObj)
      .sort()
      .reduce((acc: Record<string, unknown>, key) => {
        acc[key] = payloadObj[key];
        return acc;
      }, {});

    const hmac = crypto.createHmac("sha512", ipnSecret);
    hmac.update(JSON.stringify(sortedPayload));
    const calculatedSignature = hmac.digest("hex");

    return calculatedSignature === signature;
  } catch (error) {
    console.error("[NOWPayments] Error verifying IPN signature:", error);
    return false;
  }
}

export async function handleIPNWebhook(
  payload: IPNPayload,
  signature: string
): Promise<{ success: boolean; message: string }> {
  const config = await getConfig();
  
  if (config?.ipnSecret) {
    const isValid = verifyIPNSignature(JSON.stringify(payload), signature, config.ipnSecret);
    if (!isValid) {
      console.error("[NOWPayments] Invalid IPN signature");
      return { success: false, message: "Invalid signature" };
    }
  }

  const order = await db.getOrderByNumber(payload.order_id);
  if (!order) {
    console.error("[NOWPayments] Order not found:", payload.order_id);
    return { success: false, message: "Order not found" };
  }

  // Update order with payment info
  const updateData: Record<string, unknown> = {
    cryptoPaymentId: String(payload.payment_id),
    cryptoPaymentStatus: payload.payment_status,
  };

  // Map NOWPayments status to our order status
  const statusMap: Record<string, string> = {
    waiting: "pending",
    confirming: "processing",
    confirmed: "processing",
    sending: "processing",
    partially_paid: "processing",
    finished: "paid",
    failed: "cancelled",
    refunded: "refunded",
    expired: "cancelled",
  };

  const newStatus = statusMap[payload.payment_status];
  if (newStatus) {
    updateData.status = newStatus;
  }

  await db.updateOrder(order.id, updateData as any);

  // Log activity
  await db.createActivityLog({
    action: "crypto_payment_webhook",
    entityType: "order",
    entityId: order.id,
    details: {
      paymentId: payload.payment_id,
      status: payload.payment_status,
      amount: payload.actually_paid,
      currency: payload.pay_currency,
    },
  });

  console.log(`[NOWPayments] Order ${order.orderNumber} updated to ${newStatus}`);
  return { success: true, message: "Webhook processed" };
}

export async function isConfigured(): Promise<boolean> {
  const config = await getConfig();
  return config !== null;
}
