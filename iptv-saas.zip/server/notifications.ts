import { Server as SocketIOServer } from "socket.io";
import * as db from "./db";

export interface OrderNotification {
  type: "order_created" | "order_verified" | "order_failed" | "credentials_assigned" | "subscription_expiring";
  orderId: number;
  userId: number;
  message: string;
  data: Record<string, any>;
  timestamp: Date;
}

export interface UserNotification {
  id: number;
  userId: number;
  type: string;
  message: string;
  data: Record<string, any>;
  read: boolean;
  createdAt: Date;
}

let io: SocketIOServer | null = null;

export function setSocketIO(socketIO: SocketIOServer) {
  io = socketIO;
}

// Emit notification to specific user
export async function notifyUser(userId: number, notification: OrderNotification) {
  if (!io) {
    console.warn("[Notifications] Socket.IO not initialized");
    return;
  }

  try {
    // Save notification to database
    await db.createNotification({
      userId,
      type: notification.type,
      message: notification.message,
      data: JSON.stringify(notification.data),
      read: false,
    });

    // Emit via Socket.IO
    io.to(`user_${userId}`).emit("notification", {
      type: notification.type,
      message: notification.message,
      data: notification.data,
      timestamp: notification.timestamp,
    });

    console.log(`[Notifications] Sent to user ${userId}:`, notification.type);
  } catch (error) {
    console.error("[Notifications] Error notifying user:", error);
  }
}

// Emit notification to all admins
export async function notifyAdmins(notification: OrderNotification) {
  if (!io) {
    console.warn("[Notifications] Socket.IO not initialized");
    return;
  }

  try {
    // Get all admin users
    const admins = await db.getUsersByRole("admin");

    // Save notification for each admin
    for (const admin of admins) {
      await db.createNotification({
        userId: admin.id,
        type: notification.type,
        message: notification.message,
        data: JSON.stringify(notification.data),
        read: false,
      });

      // Emit via Socket.IO
      io.to(`user_${admin.id}`).emit("notification", {
        type: notification.type,
        message: notification.message,
        data: notification.data,
        timestamp: notification.timestamp,
      });
    }

    console.log("[Notifications] Sent to all admins:", notification.type);
  } catch (error) {
    console.error("[Notifications] Error notifying admins:", error);
  }
}

// Order created notification
export async function notifyOrderCreated(orderId: number, userId: number, planName: string) {
  await notifyUser(userId, {
    type: "order_created",
    orderId,
    userId,
    message: `Your order for ${planName} has been created. Awaiting payment verification.`,
    data: { orderId, planName },
    timestamp: new Date(),
  });

  await notifyAdmins({
    type: "order_created",
    orderId,
    userId,
    message: `New order #${orderId} created by user ${userId}`,
    data: { orderId, userId },
    timestamp: new Date(),
  });
}

// Order verified notification
export async function notifyOrderVerified(orderId: number, userId: number) {
  const order = await db.getOrderById(orderId);
  if (!order) return;

  await notifyUser(userId, {
    type: "order_verified",
    orderId,
    userId,
    message: "Your payment has been verified! Your IPTV credentials will be assigned shortly.",
    data: { orderId },
    timestamp: new Date(),
  });

  await notifyAdmins({
    type: "order_verified",
    orderId,
    userId,
    message: `Order #${orderId} payment verified`,
    data: { orderId, userId },
    timestamp: new Date(),
  });
}

// Credentials assigned notification
export async function notifyCredentialsAssigned(orderId: number, userId: number, credentialType: string) {
  const order = await db.getOrderById(orderId);
  if (!order) return;

  await notifyUser(userId, {
    type: "credentials_assigned",
    orderId,
    userId,
    message: `Your ${credentialType} IPTV credentials have been assigned! Check your account to view them.`,
    data: { orderId, credentialType },
    timestamp: new Date(),
  });
}

// Subscription expiring notification
export async function notifySubscriptionExpiring(userId: number, daysLeft: number, orderId: number) {
  await notifyUser(userId, {
    type: "subscription_expiring",
    orderId,
    userId,
    message: `Your IPTV subscription expires in ${daysLeft} days. Renew now to avoid service interruption.`,
    data: { daysLeft, orderId },
    timestamp: new Date(),
  });
}

// Mark notification as read
export async function markNotificationAsRead(notificationId: number) {
  try {
    await db.updateNotification(notificationId, { read: true });
  } catch (error) {
    console.error("[Notifications] Error marking as read:", error);
  }
}

// Get user notifications
export async function getUserNotifications(userId: number, limit = 20) {
  try {
    return await db.getUserNotifications(userId, limit);
  } catch (error) {
    console.error("[Notifications] Error getting notifications:", error);
    return [];
  }
}

// Get unread notification count
export async function getUnreadCount(userId: number): Promise<number> {
  try {
    return await db.getUnreadNotificationCount(userId);
  } catch (error) {
    console.error("[Notifications] Error getting unread count:", error);
    return 0;
  }
}
