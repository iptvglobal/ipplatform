import { describe, expect, it, vi, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the database module
vi.mock("./db", () => ({
  getUserByEmail: vi.fn(),
  createUser: vi.fn(),
  getUserByOpenId: vi.fn(),
  updateUser: vi.fn(),
  getVerificationToken: vi.fn(),
  createVerificationToken: vi.fn(),
  deleteVerificationToken: vi.fn(),
  getPasswordResetToken: vi.fn(),
  createPasswordResetToken: vi.fn(),
  deletePasswordResetToken: vi.fn(),
}));

// Mock the email module
vi.mock("./email", () => ({
  sendVerificationEmail: vi.fn().mockResolvedValue(true),
  sendPasswordResetEmail: vi.fn().mockResolvedValue(true),
}));

// Mock bcryptjs
vi.mock("bcryptjs", () => ({
  default: {
    hash: vi.fn().mockResolvedValue("hashed_password"),
    compare: vi.fn().mockResolvedValue(true),
  },
}));

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
      cookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createAuthContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user-123",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "email",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
      cookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("auth.me", () => {
  it("returns null for unauthenticated users", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.auth.me();
    
    expect(result).toBeNull();
  });

  it("returns user data for authenticated users", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.auth.me();
    
    expect(result).not.toBeNull();
    expect(result?.email).toBe("test@example.com");
    expect(result?.role).toBe("user");
  });
});

describe("auth.logout", () => {
  it("clears the session cookie and returns success", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.auth.logout();
    
    expect(result).toEqual({ success: true });
    expect(ctx.res.clearCookie).toHaveBeenCalled();
  });
});

describe("auth.register input validation", () => {
  it("rejects invalid email format", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    
    await expect(
      caller.auth.register({
        email: "invalid-email",
        password: "password123",
      })
    ).rejects.toThrow();
  });

  it("rejects password shorter than 8 characters", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    
    await expect(
      caller.auth.register({
        email: "test@example.com",
        password: "short",
      })
    ).rejects.toThrow();
  });
});

describe("auth.login input validation", () => {
  it("rejects invalid email format", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    
    await expect(
      caller.auth.login({
        email: "invalid-email",
        password: "password123",
      })
    ).rejects.toThrow();
  });
});

describe("auth.verifyEmail input validation", () => {
  it("requires a token", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    
    await expect(
      caller.auth.verifyEmail({
        token: "",
      })
    ).rejects.toThrow();
  });
});

describe("auth.forgotPassword input validation", () => {
  it("rejects invalid email format", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    
    await expect(
      caller.auth.forgotPassword({
        email: "invalid-email",
      })
    ).rejects.toThrow();
  });
});

describe("auth.resetPassword input validation", () => {
  it("rejects password shorter than 8 characters", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    
    await expect(
      caller.auth.resetPassword({
        token: "valid-token",
        password: "short",
      })
    ).rejects.toThrow();
  });
});
