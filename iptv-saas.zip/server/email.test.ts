import { describe, expect, it, vi } from "vitest";
import { ENV } from "./_core/env";

describe("Email Service Configuration", () => {
  it("should have Brevo API key configured", () => {
    expect(ENV.brevoApiKey).toBeDefined();
    expect(ENV.brevoApiKey).not.toBe("");
    expect(ENV.brevoApiKey?.length).toBeGreaterThan(0);
  });

  it("should have Brevo sender email configured", () => {
    expect(ENV.brevoSenderEmail).toBeDefined();
    expect(ENV.brevoSenderEmail).not.toBe("");
    expect(ENV.brevoSenderEmail).toMatch(/^[^\s@]+@[^\s@]+\.[^\s@]+$/);
  });

  it("should have Brevo sender name configured", () => {
    expect(ENV.brevoSenderName).toBeDefined();
    expect(ENV.brevoSenderName).not.toBe("");
    expect(ENV.brevoSenderName?.length).toBeGreaterThan(0);
  });

  it("should validate Brevo email format", () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    expect(ENV.brevoSenderEmail).toMatch(emailRegex);
  });
});

describe("Payment Service Configuration", () => {
  it("should have NOWPayments API key configured", () => {
    expect(ENV.nowpaymentsApiKey).toBeDefined();
    expect(ENV.nowpaymentsApiKey).not.toBe("");
    expect(ENV.nowpaymentsApiKey?.length).toBeGreaterThan(0);
  });

  it("should have NOWPayments IPN secret configured", () => {
    expect(ENV.nowpaymentsIpnSecret).toBeDefined();
    expect(ENV.nowpaymentsIpnSecret).not.toBe("");
    expect(ENV.nowpaymentsIpnSecret?.length).toBeGreaterThan(0);
  });

  it("should validate API key format (minimum length)", () => {
    expect(ENV.nowpaymentsApiKey?.length).toBeGreaterThanOrEqual(20);
  });
});

describe("Email Service API Call", () => {
  it("should be able to validate Brevo API connectivity", async () => {
    // This test validates that the Brevo API key format is correct
    // A real validation would require making an actual API call
    const apiKey = ENV.brevoApiKey;
    
    // Brevo API keys are typically long strings
    expect(apiKey).toBeDefined();
    expect(typeof apiKey).toBe("string");
    expect(apiKey?.length).toBeGreaterThan(10);
  });
});

describe("NOWPayments Service API Call", () => {
  it("should be able to validate NOWPayments API key format", async () => {
    // This test validates that the NOWPayments API key format is correct
    const apiKey = ENV.nowpaymentsApiKey;
    
    // NOWPayments API keys are typically long strings
    expect(apiKey).toBeDefined();
    expect(typeof apiKey).toBe("string");
    expect(apiKey?.length).toBeGreaterThan(10);
  });

  it("should have valid IPN secret for webhook verification", () => {
    const ipnSecret = ENV.nowpaymentsIpnSecret;
    
    expect(ipnSecret).toBeDefined();
    expect(typeof ipnSecret).toBe("string");
    expect(ipnSecret?.length).toBeGreaterThan(0);
  });
});
