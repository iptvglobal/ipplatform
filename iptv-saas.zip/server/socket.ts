import { Server as HttpServer } from "http";
import { Server, Socket } from "socket.io";
import cookie from "cookie";
import { sdk } from "./_core/sdk";
import * as db from "./db";

interface AuthenticatedSocket extends Socket {
  userId?: number;
  userRole?: string;
}

let io: Server | null = null;

export function initializeSocketIO(httpServer: HttpServer) {
  io = new Server(httpServer, {
    cors: {
      origin: true,
      credentials: true,
    },
    path: "/api/socket.io",
  });

  // Authentication middleware
  io.use(async (socket: AuthenticatedSocket, next) => {
    try {
      const cookies = cookie.parse(socket.handshake.headers.cookie || "");
      const sessionToken = cookies["manus_session"];
      
      if (!sessionToken) {
        return next(new Error("Authentication required"));
      }

      // Verify the session token
      const payload = await sdk.verifySession(sessionToken);
      if (!payload || !payload.openId) {
        return next(new Error("Invalid session"));
      }

      // Get user from database
      const user = await db.getUserByOpenId(payload.openId);
      if (!user) {
        return next(new Error("User not found"));
      }

      socket.userId = user.id;
      socket.userRole = user.role;
      next();
    } catch (error) {
      console.error("[Socket.IO] Auth error:", error);
      next(new Error("Authentication failed"));
    }
  });

  io.on("connection", (socket: AuthenticatedSocket) => {
    console.log(`[Socket.IO] User ${socket.userId} connected`);

    // Join user's personal room
    if (socket.userId) {
      socket.join(`user:${socket.userId}`);
      
      // If admin, join admin room
      if (socket.userRole === "admin") {
        socket.join("admins");
      }
    }

    // Handle joining a conversation
    socket.on("join:conversation", async (conversationId: number) => {
      if (!socket.userId) return;
      
      // Verify user has access to this conversation
      const conversation = await db.getConversationById(conversationId);
      if (!conversation) return;
      
      // Only allow if user owns the conversation or is admin
      if (conversation.userId !== socket.userId && socket.userRole !== "admin") {
        return;
      }
      
      socket.join(`conversation:${conversationId}`);
      console.log(`[Socket.IO] User ${socket.userId} joined conversation ${conversationId}`);
    });

    // Handle leaving a conversation
    socket.on("leave:conversation", (conversationId: number) => {
      socket.leave(`conversation:${conversationId}`);
    });

    // Handle sending a message
    socket.on("message:send", async (data: { conversationId: number; message: string }) => {
      if (!socket.userId) return;
      
      try {
        const { conversationId, message } = data;
        
        // Get or verify conversation
        let conversation = await db.getConversationById(conversationId);
        
        if (!conversation) {
          // Create new conversation if it doesn't exist and user is sending first message
          const newConv = await db.getOrCreateConversation(socket.userId);
          conversation = newConv;
        }
        
        // Verify access
        if (conversation.userId !== socket.userId && socket.userRole !== "admin") {
          return;
        }
        
        // Determine sender role
        const senderRole = socket.userRole === "admin" ? "admin" : "user";
        
        // Save message to database
        const savedMessage = await db.createMessage({
          conversationId: conversation.id,
          senderId: socket.userId,
          senderRole,
          message,
        });
        
        // Update conversation timestamp
        await db.updateConversation(conversation.id, { updatedAt: new Date() });
        
        // Emit to conversation room
        io?.to(`conversation:${conversation.id}`).emit("message:new", {
          id: savedMessage,
          conversationId: conversation.id,
          senderId: socket.userId,
          senderRole,
          message,
          createdAt: new Date(),
        });
        
        // Notify admins of new user message
        if (senderRole === "user") {
          io?.to("admins").emit("conversation:updated", {
            conversationId: conversation.id,
            lastMessage: message,
            userId: socket.userId,
          });
        }
        
        // Notify user of admin reply
        if (senderRole === "admin") {
          io?.to(`user:${conversation.userId}`).emit("message:new", {
            id: savedMessage,
            conversationId: conversation.id,
            senderId: socket.userId,
            senderRole,
            message,
            createdAt: new Date(),
          });
        }
      } catch (error) {
        console.error("[Socket.IO] Message send error:", error);
        socket.emit("error", { message: "Failed to send message" });
      }
    });

    // Handle typing indicator
    socket.on("typing:start", (conversationId: number) => {
      socket.to(`conversation:${conversationId}`).emit("typing:start", {
        userId: socket.userId,
        role: socket.userRole,
      });
    });

    socket.on("typing:stop", (conversationId: number) => {
      socket.to(`conversation:${conversationId}`).emit("typing:stop", {
        userId: socket.userId,
      });
    });

    socket.on("disconnect", () => {
      console.log(`[Socket.IO] User ${socket.userId} disconnected`);
    });
  });

  return io;
}

// Helper to emit events from other parts of the application
export function emitToUser(userId: number, event: string, data: any) {
  io?.to(`user:${userId}`).emit(event, data);
}

export function emitToAdmins(event: string, data: any) {
  io?.to("admins").emit(event, data);
}

export function emitToConversation(conversationId: number, event: string, data: any) {
  io?.to(`conversation:${conversationId}`).emit(event, data);
}

export function getIO() {
  return io;
}
