import { createClient } from "@supabase/supabase-js";
import { ENV } from "./_core/env";

// Supabase client for server-side operations
export const supabase = createClient(
  ENV.supabaseUrl,
  ENV.supabaseServiceRoleKey,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  }
);

// Verify Supabase connection
export async function verifySupabaseConnection(): Promise<boolean> {
  try {
    const { data, error } = await supabase.auth.admin.listUsers();
    if (error) {
      console.error("[Supabase] Connection error:", error.message);
      return false;
    }
    console.log("[Supabase] Connected successfully");
    return true;
  } catch (error) {
    console.error("[Supabase] Connection failed:", error);
    return false;
  }
}

// Supabase Auth functions
export async function createUserWithEmail(
  email: string,
  password: string,
  metadata?: Record<string, any>
) {
  try {
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: false,
      user_metadata: metadata,
    });

    if (error) {
      console.error("[Supabase Auth] Failed to create user:", error.message);
      return { success: false, error: error.message };
    }

    console.log("[Supabase Auth] User created:", data.user?.id);
    return { success: true, user: data.user };
  } catch (error) {
    console.error("[Supabase Auth] Error creating user:", error);
    return { success: false, error: String(error) };
  }
}

export async function getUserByEmail(email: string) {
  try {
    const { data, error } = await supabase.auth.admin.listUsers();

    if (error) {
      console.error("[Supabase Auth] Failed to list users:", error.message);
      return null;
    }

    return data.users.find((u) => u.email === email) || null;
  } catch (error) {
    console.error("[Supabase Auth] Error getting user:", error);
    return null;
  }
}

export async function getUserById(userId: string) {
  try {
    const { data, error } = await supabase.auth.admin.getUserById(userId);

    if (error) {
      console.error("[Supabase Auth] Failed to get user:", error.message);
      return null;
    }

    return data.user;
  } catch (error) {
    console.error("[Supabase Auth] Error getting user:", error);
    return null;
  }
}

export async function updateUserPassword(userId: string, password: string) {
  try {
    const { data, error } = await supabase.auth.admin.updateUserById(userId, {
      password,
    });

    if (error) {
      console.error("[Supabase Auth] Failed to update password:", error.message);
      return { success: false, error: error.message };
    }

    return { success: true, user: data.user };
  } catch (error) {
    console.error("[Supabase Auth] Error updating password:", error);
    return { success: false, error: String(error) };
  }
}

export async function confirmUserEmail(userId: string) {
  try {
    const { data, error } = await supabase.auth.admin.updateUserById(userId, {
      email_confirm: true,
    });

    if (error) {
      console.error("[Supabase Auth] Failed to confirm email:", error.message);
      return { success: false, error: error.message };
    }

    return { success: true, user: data.user };
  } catch (error) {
    console.error("[Supabase Auth] Error confirming email:", error);
    return { success: false, error: String(error) };
  }
}

export async function sendPasswordResetEmail(email: string) {
  try {
    const { data, error } = await supabase.auth.admin.generateLink({
      type: "recovery",
      email,
      options: {
        redirectTo: `${process.env.APP_URL}/reset-password`,
      },
    });

    if (error) {
      console.error("[Supabase Auth] Failed to send reset email:", error.message);
      return { success: false, error: error.message };
    }

    return { success: true, link: data.properties?.action_link };
  } catch (error) {
    console.error("[Supabase Auth] Error sending reset email:", error);
    return { success: false, error: String(error) };
  }
}

export async function sendEmailConfirmation(email: string) {
  try {
    const { data, error } = await supabase.auth.admin.generateLink({
      type: "email_change_new",
      email,
      newEmail: email,
      options: {
        redirectTo: `${process.env.APP_URL}/verify-email`,
      },
    });

    if (error) {
      console.error("[Supabase Auth] Failed to send confirmation email:", error.message);
      return { success: false, error: error.message };
    }

    return { success: true, link: data.properties?.action_link };
  } catch (error) {
    console.error("[Supabase Auth] Error sending confirmation email:", error);
    return { success: false, error: String(error) };
  }
}
