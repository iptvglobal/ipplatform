import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { sdk } from "./_core/sdk";
import * as db from "./db";
import * as auth from "./auth";
import * as email from "./email";
import * as nowpayments from "./nowpayments";

const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1000;

// Admin procedure - requires admin role
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

// ==================== AUTH ROUTER ====================
const authRouter = router({
  me: publicProcedure.query((opts) => opts.ctx.user),
  
  logout: publicProcedure.mutation(({ ctx }) => {
    const cookieOptions = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    return { success: true } as const;
  }),

  register: publicProcedure
    .input(z.object({
      email: z.string().email(),
      password: z.string().min(8),
      name: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const result = await auth.registerUser(input.email, input.password, input.name);
      
      // Send verification email
      await email.sendVerificationEmail(input.email, result.verificationToken, input.name);
      
      return { success: true, message: "Registration successful. Please check your email to verify your account." };
    }),

  login: publicProcedure
    .input(z.object({
      email: z.string().email(),
      password: z.string(),
    }))
    .mutation(async ({ input, ctx }) => {
      const user = await auth.loginUser(input.email, input.password);
      
      // Check if email is verified
      if (!user.emailVerified) {
        throw new TRPCError({
          code: "FORBIDDEN",
          message: "Please verify your email before logging in. Check your inbox for the verification link.",
        });
      }
      
      // Create session token
      const sessionToken = await sdk.createSessionToken(user.openId, {
        name: user.name || "",
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });

      return { 
        success: true, 
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          emailVerified: user.emailVerified,
        }
      };
    }),

  verifyEmail: publicProcedure
    .input(z.object({ token: z.string() }))
    .mutation(async ({ input, ctx }) => {
      const user = await auth.verifyEmail(input.token);
      
      // Create session token for verified user
      const sessionToken = await sdk.createSessionToken(user.openId, {
        name: user.name || "",
        expiresInMs: ONE_YEAR_MS,
      });

      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.cookie(COOKIE_NAME, sessionToken, { ...cookieOptions, maxAge: ONE_YEAR_MS });
      
      return { 
        success: true, 
        message: "Email verified successfully!",
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          emailVerified: user.emailVerified,
        }
      };
    }),

  forgotPassword: publicProcedure
    .input(z.object({ email: z.string().email() }))
    .mutation(async ({ input }) => {
      const result = await auth.requestPasswordReset(input.email);
      
      if (result.resetToken && result.email) {
        await email.sendPasswordResetEmail(result.email, result.resetToken);
      }
      
      return { success: true, message: "If an account exists with this email, you will receive a password reset link." };
    }),

  resetPassword: publicProcedure
    .input(z.object({
      token: z.string(),
      password: z.string().min(8),
    }))
    .mutation(async ({ input }) => {
      await auth.resetPassword(input.token, input.password);
      return { success: true, message: "Password reset successfully!" };
    }),

  resendVerification: publicProcedure
    .input(z.object({ email: z.string().email() }))
    .mutation(async ({ input }) => {
      const result = await auth.resendVerificationEmail(input.email);
      await email.sendVerificationEmail(result.email, result.verificationToken);
      return { success: true, message: "Verification email sent!" };
    }),
});

// ==================== PLANS ROUTER ====================
const plansRouter = router({
  list: publicProcedure.query(async () => {
    return db.getActivePlans();
  }),

  get: publicProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      return db.getPlanById(input.id);
    }),

  calculatePrice: publicProcedure
    .input(z.object({
      planId: z.number(),
      connections: z.number().min(1).max(10),
    }))
    .query(async ({ input }) => {
      const plan = await db.getPlanById(input.planId);
      if (!plan) throw new TRPCError({ code: "NOT_FOUND", message: "Plan not found" });
      
      const basePrice = parseFloat(plan.basePrice);
      const pricePerConnection = parseFloat(plan.pricePerConnection);
      const totalPrice = basePrice + (pricePerConnection * (input.connections - 1));
      
      return {
        basePrice,
        pricePerConnection,
        connections: input.connections,
        totalPrice: Math.round(totalPrice * 100) / 100,
      };
    }),
});

// ==================== PAYMENT METHODS ROUTER ====================
const paymentMethodsRouter = router({
  list: publicProcedure.query(async () => {
    return db.getActivePaymentMethods();
  }),

  getForPlan: publicProcedure
    .input(z.object({ planId: z.number() }))
    .query(async ({ input }) => {
      const methods = await db.getActivePaymentMethods();
      const planLinks = await db.getPlanPaymentLinks(input.planId);
      
      return methods.map(method => {
        const planLink = planLinks.find(l => l.paymentMethodId === method.id);
        return {
          ...method,
          customLink: planLink?.customLink || null,
          customInstructions: planLink?.customInstructions || null,
        };
      });
    }),

  cryptoStatus: publicProcedure.query(async () => {
    const isConfigured = await nowpayments.isConfigured();
    return { isConfigured };
  }),
});

// ==================== ORDERS ROUTER ====================
const ordersRouter = router({
  create: protectedProcedure
    .input(z.object({
      planId: z.number(),
      connections: z.number().min(1).max(10),
      paymentMethodId: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      const plan = await db.getPlanById(input.planId);
      if (!plan) throw new TRPCError({ code: "NOT_FOUND", message: "Plan not found" });

      const paymentMethod = await db.getPaymentMethodById(input.paymentMethodId);
      if (!paymentMethod) throw new TRPCError({ code: "NOT_FOUND", message: "Payment method not found" });

      // Calculate price
      const basePrice = parseFloat(plan.basePrice);
      const pricePerConnection = parseFloat(plan.pricePerConnection);
      const totalPrice = basePrice + (pricePerConnection * (input.connections - 1));

      // Generate order number
      const orderNumber = auth.generateOrderNumber();

      // Create order
      const orderId = await db.createOrder({
        orderNumber,
        userId: ctx.user.id,
        planId: input.planId,
        connections: input.connections,
        totalPrice: String(Math.round(totalPrice * 100) / 100),
        status: "pending",
        paymentMethodId: input.paymentMethodId,
      });

      // If crypto payment, create invoice
      let cryptoPaymentUrl: string | null = null;
      if (paymentMethod.type === "crypto") {
        const invoice = await nowpayments.createInvoice({
          priceAmount: totalPrice,
          priceCurrency: "USD",
          orderId: orderNumber,
          orderDescription: `${plan.name} - ${input.connections} connection(s)`,
        });
        
        if (invoice) {
          await db.updateOrder(orderId, {
            cryptoPaymentId: invoice.id,
            cryptoPaymentUrl: invoice.invoice_url,
          });
          cryptoPaymentUrl = invoice.invoice_url;
        }
      }

      // Send order confirmation email
      await email.sendOrderConfirmationEmail(
        ctx.user.email,
        orderNumber,
        plan.name,
        String(totalPrice),
        ctx.user.name || undefined
      );

      // Log activity
      await db.createActivityLog({
        userId: ctx.user.id,
        action: "order_created",
        entityType: "order",
        entityId: orderId,
        details: { orderNumber, planId: input.planId, connections: input.connections, totalPrice },
      });

      return { 
        orderId, 
        orderNumber, 
        totalPrice,
        cryptoPaymentUrl,
      };
    }),

  list: protectedProcedure.query(async ({ ctx }) => {
    return db.getUserOrders(ctx.user.id);
  }),

  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input, ctx }) => {
      const order = await db.getOrderById(input.id);
      if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });
      if (order.userId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Access denied" });
      }
      
      const plan = await db.getPlanById(order.planId);
      const paymentMethod = order.paymentMethodId ? await db.getPaymentMethodById(order.paymentMethodId) : null;
      const credentials = await db.getOrderCredentials(order.id);
      
      return { ...order, plan, paymentMethod, credentials };
    }),

  uploadProof: protectedProcedure
    .input(z.object({
      orderId: z.number(),
      proofUrl: z.string().url(),
      reference: z.string().optional(),
    }))
    .mutation(async ({ input, ctx }) => {
      const order = await db.getOrderById(input.orderId);
      if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });
      if (order.userId !== ctx.user.id) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Access denied" });
      }

      await db.updateOrder(input.orderId, {
        paymentProof: input.proofUrl,
        paymentReference: input.reference || null,
        status: "processing",
      });

      await db.createActivityLog({
        userId: ctx.user.id,
        action: "payment_proof_uploaded",
        entityType: "order",
        entityId: input.orderId,
      });

      return { success: true };
    }),
});

// ==================== CREDENTIALS ROUTER ====================
const credentialsRouter = router({
  list: protectedProcedure.query(async ({ ctx }) => {
    return db.getUserCredentials(ctx.user.id);
  }),

  get: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ input, ctx }) => {
      const credential = await db.getCredentialById(input.id);
      if (!credential) throw new TRPCError({ code: "NOT_FOUND", message: "Credential not found" });
      if (credential.userId !== ctx.user.id && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Access denied" });
      }
      return credential;
    }),
});

// ==================== CHAT ROUTER ====================
const chatRouter = router({
  getConversation: protectedProcedure.query(async ({ ctx }) => {
    const conversation = await db.getOrCreateConversation(ctx.user.id);
    const messages = await db.getConversationMessages(conversation.id);
    return { conversation, messages };
  }),

  sendMessage: protectedProcedure
    .input(z.object({ message: z.string().min(1) }))
    .mutation(async ({ input, ctx }) => {
      const conversation = await db.getOrCreateConversation(ctx.user.id);
      
      const messageId = await db.createMessage({
        conversationId: conversation.id,
        senderId: ctx.user.id,
        senderRole: ctx.user.role === "admin" ? "admin" : "user",
        message: input.message,
      });

      return { messageId, conversationId: conversation.id };
    }),

  markAsRead: protectedProcedure
    .input(z.object({ conversationId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      await db.markMessagesAsRead(input.conversationId, ctx.user.role === "admin" ? "admin" : "user");
      return { success: true };
    }),
});

// ==================== ADMIN ROUTER ====================
const adminRouter = router({
  // Dashboard stats
  stats: adminProcedure.query(async () => {
    const [userCount, orderCount, totalRevenue, pendingOrders] = await Promise.all([
      db.getUserCount(),
      db.getOrderCount(),
      db.getTotalRevenue(),
      db.getOrdersByStatus("pending"),
    ]);

    return {
      userCount,
      orderCount,
      totalRevenue,
      pendingOrderCount: pendingOrders.length,
    };
  }),

  // User management
  users: router({
    list: adminProcedure
      .input(z.object({ limit: z.number().default(100), offset: z.number().default(0) }).optional())
      .query(async ({ input }) => {
        return db.getAllUsers(input?.limit || 100, input?.offset || 0);
      }),

    get: adminProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return db.getUserById(input.id);
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        role: z.enum(["user", "admin"]).optional(),
        status: z.enum(["active", "suspended", "banned"]).optional(),
      }))
      .mutation(async ({ input }) => {
        await db.updateUser(input.id, {
          role: input.role,
          status: input.status,
        });
        return { success: true };
      }),
  }),

  // Order management
  orders: router({
    list: adminProcedure
      .input(z.object({ 
        limit: z.number().default(100), 
        offset: z.number().default(0),
        status: z.string().optional(),
      }).optional())
      .query(async ({ input }) => {
        if (input?.status) {
          return db.getOrdersByStatus(input.status);
        }
        return db.getAllOrders(input?.limit || 100, input?.offset || 0);
      }),

    updateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["pending", "processing", "verified", "paid", "cancelled", "refunded"]),
        adminNotes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const order = await db.getOrderById(input.id);
        if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });

        await db.updateOrder(input.id, {
          status: input.status,
          adminNotes: input.adminNotes,
        });

        // If verified/paid, send email notification
        if (input.status === "paid" || input.status === "verified") {
          const user = await db.getUserById(order.userId);
          if (user) {
            await email.sendPaymentVerifiedEmail(user.email, order.orderNumber, user.name || undefined);
          }
        }

        await db.createActivityLog({
          userId: ctx.user.id,
          action: "order_status_updated",
          entityType: "order",
          entityId: input.id,
          details: { oldStatus: order.status, newStatus: input.status },
        });

        return { success: true };
      }),
  }),

  // Plan management
  plans: router({
    list: adminProcedure.query(async () => {
      return db.getAllPlans();
    }),

    create: adminProcedure
      .input(z.object({
        name: z.string(),
        description: z.string().optional(),
        basePrice: z.string(),
        pricePerConnection: z.string(),
        minConnections: z.number().default(1),
        maxConnections: z.number().default(10),
        durationDays: z.number(),
        features: z.array(z.string()).optional(),
        isActive: z.boolean().default(true),
        sortOrder: z.number().default(0),
      }))
      .mutation(async ({ input }) => {
        const planId = await db.createPlan(input);
        return { planId };
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        description: z.string().optional(),
        basePrice: z.string().optional(),
        pricePerConnection: z.string().optional(),
        minConnections: z.number().optional(),
        maxConnections: z.number().optional(),
        durationDays: z.number().optional(),
        features: z.array(z.string()).optional(),
        isActive: z.boolean().optional(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updatePlan(id, data);
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deletePlan(input.id);
        return { success: true };
      }),
  }),

  // Payment method management
  paymentMethods: router({
    list: adminProcedure.query(async () => {
      return db.getAllPaymentMethods();
    }),

    create: adminProcedure
      .input(z.object({
        name: z.string(),
        type: z.enum(["crypto", "manual_card", "manual_paypal", "manual_custom"]),
        instructions: z.string().optional(),
        paymentLink: z.string().optional(),
        hasLink: z.boolean().default(false),
        iconUrl: z.string().optional(),
        isActive: z.boolean().default(true),
        sortOrder: z.number().default(0),
      }))
      .mutation(async ({ input }) => {
        const methodId = await db.createPaymentMethod(input);
        return { methodId };
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().optional(),
        instructions: z.string().optional(),
        paymentLink: z.string().optional(),
        hasLink: z.boolean().optional(),
        iconUrl: z.string().optional(),
        isActive: z.boolean().optional(),
        sortOrder: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updatePaymentMethod(id, data);
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deletePaymentMethod(input.id);
        return { success: true };
      }),

    setPlanLink: adminProcedure
      .input(z.object({
        planId: z.number(),
        paymentMethodId: z.number(),
        customLink: z.string().optional(),
        customInstructions: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.upsertPlanPaymentLink(input);
        return { success: true };
      }),
  }),

  // Credential management
  credentials: router({
    list: adminProcedure
      .input(z.object({ limit: z.number().default(100), offset: z.number().default(0) }).optional())
      .query(async ({ input }) => {
        return db.getAllCredentials(input?.limit || 100, input?.offset || 0);
      }),

    create: adminProcedure
      .input(z.object({
        orderId: z.number().optional(),
        userId: z.number().optional(),
        type: z.enum(["xtream", "m3u", "portal"]),
        serverUrl: z.string().optional(),
        username: z.string().optional(),
        password: z.string().optional(),
        m3uUrl: z.string().optional(),
        portalUrl: z.string().optional(),
        macAddress: z.string().optional(),
        connectionNumber: z.number().default(1),
        expiresAt: z.date().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const credentialId = await db.createCredential(input);
        return { credentialId };
      }),

    update: adminProcedure
      .input(z.object({
        id: z.number(),
        serverUrl: z.string().optional(),
        username: z.string().optional(),
        password: z.string().optional(),
        m3uUrl: z.string().optional(),
        portalUrl: z.string().optional(),
        macAddress: z.string().optional(),
        connectionNumber: z.number().optional(),
        expiresAt: z.date().optional(),
        isActive: z.boolean().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await db.updateCredential(id, data);
        return { success: true };
      }),

    delete: adminProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await db.deleteCredential(input.id);
        return { success: true };
      }),

    assignToOrder: adminProcedure
      .input(z.object({
        orderId: z.number(),
        credentials: z.array(z.object({
          type: z.enum(["xtream", "m3u", "portal"]),
          serverUrl: z.string().optional(),
          username: z.string().optional(),
          password: z.string().optional(),
          m3uUrl: z.string().optional(),
          portalUrl: z.string().optional(),
          macAddress: z.string().optional(),
          connectionNumber: z.number(),
        })),
      }))
      .mutation(async ({ input }) => {
        const order = await db.getOrderById(input.orderId);
        if (!order) throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });

        for (const cred of input.credentials) {
          await db.createCredential({
            ...cred,
            orderId: input.orderId,
            userId: order.userId,
          });
        }

        // Update order status to paid
        await db.updateOrder(input.orderId, { status: "paid" });

        return { success: true };
      }),
  }),

  // Chat management
  chat: router({
    conversations: adminProcedure.query(async () => {
      const conversations = await db.getAllConversations();
      return conversations;
    }),

    messages: adminProcedure
      .input(z.object({ conversationId: z.number() }))
      .query(async ({ input }) => {
        return db.getConversationMessages(input.conversationId);
      }),

    reply: adminProcedure
      .input(z.object({
        conversationId: z.number(),
        message: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        const messageId = await db.createMessage({
          conversationId: input.conversationId,
          senderId: ctx.user.id,
          senderRole: "admin",
          message: input.message,
        });
        return { messageId };
      }),

    closeConversation: adminProcedure
      .input(z.object({ conversationId: z.number() }))
      .mutation(async ({ input }) => {
        await db.updateConversation(input.conversationId, { status: "closed" });
        return { success: true };
      }),
  }),

  // Email template management
  emailTemplates: router({
    list: adminProcedure.query(async () => {
      return db.getAllEmailTemplates();
    }),

    get: adminProcedure
      .input(z.object({ name: z.string() }))
      .query(async ({ input }) => {
        return db.getEmailTemplate(input.name);
      }),

    update: adminProcedure
      .input(z.object({
        name: z.string(),
        subject: z.string(),
        htmlContent: z.string(),
        textContent: z.string().optional(),
        variables: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input }) => {
        await db.upsertEmailTemplate(input);
        return { success: true };
      }),
  }),

  // Activity logs
  logs: router({
    list: adminProcedure
      .input(z.object({ limit: z.number().default(100), offset: z.number().default(0) }).optional())
      .query(async ({ input }) => {
        return db.getActivityLogs(input?.limit || 100, input?.offset || 0);
      }),
  }),

  // System settings
  settings: router({
    get: adminProcedure
      .input(z.object({ key: z.string() }))
      .query(async ({ input }) => {
        return db.getSetting(input.key);
      }),

    set: adminProcedure
      .input(z.object({
        key: z.string(),
        value: z.string(),
        type: z.enum(["string", "number", "boolean", "json"]).default("string"),
        description: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        await db.upsertSetting(input);
        return { success: true };
      }),

    list: adminProcedure.query(async () => {
      return db.getAllSettings();
    }),
  }),
});

export const appRouter = router({
  system: systemRouter,
  auth: authRouter,
  chat: chatRouter,
  plans: plansRouter,
  paymentMethods: paymentMethodsRouter,
  orders: ordersRouter,
  credentials: credentialsRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;
