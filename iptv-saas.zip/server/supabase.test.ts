import { describe, expect, it } from "vitest";
import { ENV } from "./_core/env";

describe("Supabase Configuration", () => {
  it("should have Supabase URL configured", () => {
    expect(ENV.supabaseUrl).toBeDefined();
    expect(ENV.supabaseUrl).not.toBe("");
    expect(ENV.supabaseUrl).toContain("supabase.co");
  });

  it("should have Supabase anon key configured", () => {
    expect(ENV.supabaseAnonKey).toBeDefined();
    expect(ENV.supabaseAnonKey).not.toBe("");
    expect(ENV.supabaseAnonKey?.length).toBeGreaterThan(10);
  });

  it("should have Supabase service role key configured", () => {
    expect(ENV.supabaseServiceRoleKey).toBeDefined();
    expect(ENV.supabaseServiceRoleKey).not.toBe("");
    expect(ENV.supabaseServiceRoleKey?.length).toBeGreaterThan(10);
  });

  it("should have valid Supabase URL format", () => {
    const urlRegex = /^https:\/\/[a-z0-9]+\.supabase\.co$/;
    expect(ENV.supabaseUrl).toMatch(urlRegex);
  });

  it("should have different anon and service role keys", () => {
    expect(ENV.supabaseAnonKey).not.toBe(ENV.supabaseServiceRoleKey);
  });
});
