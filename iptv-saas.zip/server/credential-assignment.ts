import * as db from "./db";
import * as notifications from "./notifications";

export interface CredentialAssignmentResult {
  success: boolean;
  credentialId?: number;
  credentialType?: string;
  error?: string;
}

/**
 * Automatically assign IPTV credentials to a verified order
 * Selects available credentials based on connection count and credential type
 */
export async function assignCredentialsToOrder(
  orderId: number
): Promise<CredentialAssignmentResult> {
  try {
    // Get order details
    const order = await db.getOrderById(orderId);
    if (!order) {
      return { success: false, error: "Order not found" };
    }

    if (order.status !== "verified" && order.status !== "paid") {
      return { success: false, error: "Order must be verified or paid before assigning credentials" };
    }

    // Get plan details to know how many connections are needed
    const plan = await db.getSubscriptionPlanById(order.planId);
    if (!plan) {
      return { success: false, error: "Plan not found" };
    }

    const connectionsNeeded = order.connections || plan.maxConnections;

    // Try to find available credentials in order of preference: Xtream > M3U > Portal
    const credentialTypes = ["xtream", "m3u", "portal"];

    for (const credentialType of credentialTypes) {
      const credential = await findAvailableCredential(credentialType, connectionsNeeded);

      if (credential) {
        // Assign credential to order
        await db.assignCredentialToOrder(orderId, credential.id);

        // Update credential usage
        await db.updateCredential(credential.id, {
          usedConnections: (credential.usedConnections || 0) + connectionsNeeded,
        });

        // Log activity
        await db.createActivityLog({
          userId: order.userId,
          action: "credential_assigned",
          entityType: "order",
          entityId: orderId,
          details: {
            credentialId: credential.id,
            credentialType,
            connectionsAssigned: connectionsNeeded,
          },
        });

        // Notify user
        await notifications.notifyCredentialsAssigned(
          orderId,
          order.userId,
          credentialType.toUpperCase()
        );

        return {
          success: true,
          credentialId: credential.id,
          credentialType,
        };
      }
    }

    return {
      success: false,
      error: "No available credentials found for this order",
    };
  } catch (error) {
    console.error("[Credential Assignment] Error:", error);
    return {
      success: false,
      error: String(error),
    };
  }
}

/**
 * Find an available credential of a specific type with enough connections
 */
async function findAvailableCredential(
  credentialType: string,
  connectionsNeeded: number
) {
  try {
    const credentials = await db.getIptvCredentialsByType(credentialType);

    // Find first credential with enough available connections
    for (const credential of credentials) {
      const availableConnections = (credential.maxConnections || 0) - (credential.usedConnections || 0);

      if (availableConnections >= connectionsNeeded) {
        return credential;
      }
    }

    return null;
  } catch (error) {
    console.error("[Credential Assignment] Error finding credentials:", error);
    return null;
  }
}

/**
 * Batch assign credentials to all pending verified orders
 * Run this periodically (e.g., every 5 minutes) to auto-assign credentials
 */
export async function batchAssignCredentials() {
  try {
    // Get all verified orders without credentials
    const orders = await db.getVerifiedOrdersWithoutCredentials();

    console.log(`[Credential Assignment] Processing ${orders.length} orders`);

    let successCount = 0;
    let failureCount = 0;

    for (const order of orders) {
      const result = await assignCredentialsToOrder(order.id);

      if (result.success) {
        successCount++;
      } else {
        failureCount++;
        console.warn(
          `[Credential Assignment] Failed to assign credentials to order ${order.id}:`,
          result.error
        );
      }
    }

    console.log(
      `[Credential Assignment] Batch complete: ${successCount} succeeded, ${failureCount} failed`
    );

    return { successCount, failureCount };
  } catch (error) {
    console.error("[Credential Assignment] Batch error:", error);
    throw error;
  }
}

/**
 * Reclaim credentials when order expires or is cancelled
 */
export async function reclaimCredentials(orderId: number) {
  try {
    const order = await db.getOrderById(orderId);
    if (!order) {
      return { success: false, error: "Order not found" };
    }

    // Get assigned credentials
    const credentials = await db.getOrderCredentials(orderId);

    for (const credential of credentials) {
      // Reduce used connections
      const newUsedConnections = Math.max(
        0,
        (credential.usedConnections || 0) - (order.connections || 1)
      );

      await db.updateCredential(credential.id, {
        usedConnections: newUsedConnections,
      });

      // Remove assignment
      await db.removeCredentialFromOrder(orderId);
    }

    // Log activity
    await db.createActivityLog({
      userId: order.userId,
      action: "credentials_reclaimed",
      entityType: "order",
      entityId: orderId,
      details: {
        credentialCount: credentials.length,
      },
    });

    return { success: true };
  } catch (error) {
    console.error("[Credential Assignment] Reclaim error:", error);
    return { success: false, error: String(error) };
  }
}
