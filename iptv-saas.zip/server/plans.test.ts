import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the database module
vi.mock("./db", () => ({
  getActivePlans: vi.fn().mockResolvedValue([
    {
      id: 1,
      name: "Basic",
      description: "Basic IPTV plan",
      basePrice: "9.99",
      pricePerConnection: "2.00",
      durationDays: 30,
      minConnections: 1,
      maxConnections: 5,
      features: "HD Quality\n24/7 Support",
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 2,
      name: "Premium",
      description: "Premium IPTV plan",
      basePrice: "19.99",
      pricePerConnection: "3.00",
      durationDays: 30,
      minConnections: 1,
      maxConnections: 10,
      features: "4K Quality\nPriority Support\nAll Channels",
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ]),
  getPlanById: vi.fn().mockResolvedValue({
    id: 1,
    name: "Basic",
    description: "Basic IPTV plan",
    basePrice: "9.99",
    pricePerConnection: "2.00",
    durationDays: 30,
    minConnections: 1,
    maxConnections: 5,
    features: "HD Quality\n24/7 Support",
    isActive: true,
    createdAt: new Date(),
    updatedAt: new Date(),
  }),
  getActivePaymentMethods: vi.fn().mockResolvedValue([
    {
      id: 1,
      name: "Bitcoin",
      type: "crypto",
      instructions: "Pay with Bitcoin",
      isActive: true,
    },
    {
      id: 2,
      name: "Bank Transfer",
      type: "manual",
      instructions: "Transfer to account...",
      isActive: true,
    },
  ]),
  getUserByOpenId: vi.fn(),
}));

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
      cookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

function createAuthContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-user-123",
      email: "test@example.com",
      name: "Test User",
      loginMethod: "email",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
      cookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("plans.list", () => {
  it("returns list of active plans for authenticated users", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.plans.list();
    
    expect(result).toBeInstanceOf(Array);
    expect(result.length).toBeGreaterThan(0);
    expect(result[0]).toHaveProperty("name");
    expect(result[0]).toHaveProperty("basePrice");
  });

  // Note: plans.list is a public procedure, so it doesn't throw for unauthenticated users
  it("returns plans even for unauthenticated users (public endpoint)", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.plans.list();
    expect(result).toBeInstanceOf(Array);
  });
});

describe("plans.get", () => {
  it("returns plan details for valid ID", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.plans.get({ id: 1 });
    
    expect(result).not.toBeNull();
    expect(result?.name).toBe("Basic");
  });
});

describe("paymentMethods.list", () => {
  it("returns list of active payment methods", async () => {
    const ctx = createAuthContext();
    const caller = appRouter.createCaller(ctx);
    
    const result = await caller.paymentMethods.list();
    
    expect(result).toBeInstanceOf(Array);
    expect(result.length).toBeGreaterThan(0);
    expect(result[0]).toHaveProperty("name");
    expect(result[0]).toHaveProperty("type");
  });
});

describe("price calculation", () => {
  it("calculates correct total price based on connections", () => {
    const basePrice = 9.99;
    const pricePerConnection = 2.00;
    const connections = 3;
    
    // Price formula: basePrice + (pricePerConnection * (connections - 1))
    const expectedPrice = basePrice + (pricePerConnection * (connections - 1));
    
    expect(expectedPrice).toBe(13.99);
  });

  it("calculates base price for single connection", () => {
    const basePrice = 9.99;
    const pricePerConnection = 2.00;
    const connections = 1;
    
    const expectedPrice = basePrice + (pricePerConnection * (connections - 1));
    
    expect(expectedPrice).toBe(9.99);
  });

  it("calculates max price for maximum connections", () => {
    const basePrice = 9.99;
    const pricePerConnection = 2.00;
    const connections = 10;
    
    const expectedPrice = basePrice + (pricePerConnection * (connections - 1));
    
    expect(expectedPrice).toBeCloseTo(27.99, 2);
  });
});
