import bcrypt from "bcryptjs";
import { nanoid } from "nanoid";
import * as db from "./db";
import { TRPCError } from "@trpc/server";

const SALT_ROUNDS = 12;
const TOKEN_EXPIRY_HOURS = 24;
const PASSWORD_RESET_EXPIRY_HOURS = 1;

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function generateToken(): string {
  return nanoid(32);
}

export function generateOrderNumber(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = nanoid(6).toUpperCase();
  return `ORD-${timestamp}-${random}`;
}

export async function registerUser(email: string, password: string, name?: string) {
  // Check if user already exists
  const existingUser = await db.getUserByEmail(email);
  if (existingUser) {
    throw new TRPCError({
      code: "CONFLICT",
      message: "An account with this email already exists",
    });
  }

  // Hash password
  const passwordHash = await hashPassword(password);
  
  // Generate verification token
  const verificationToken = generateToken();
  const verificationExpires = new Date(Date.now() + TOKEN_EXPIRY_HOURS * 60 * 60 * 1000);

  // Create user with openId as a unique identifier
  const openId = `email_${nanoid(16)}`;
  
  const userId = await db.createUser({
    openId,
    email,
    passwordHash,
    name: name || null,
    loginMethod: "email",
    emailVerified: false,
    emailVerificationToken: verificationToken,
    emailVerificationExpires: verificationExpires,
    role: "user",
  });

  // Log activity
  await db.createActivityLog({
    userId,
    action: "user_registered",
    entityType: "user",
    entityId: userId,
    details: { email, method: "email" },
  });

  return {
    userId,
    verificationToken,
    email,
  };
}

export async function loginUser(email: string, password: string) {
  const user = await db.getUserByEmail(email);
  
  if (!user) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "Invalid email or password",
    });
  }

  if (user.status === "banned") {
    throw new TRPCError({
      code: "FORBIDDEN",
      message: "Your account has been suspended. Please contact support.",
    });
  }

  if (!user.passwordHash) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "Please use OAuth to login or reset your password",
    });
  }

  const isValid = await verifyPassword(password, user.passwordHash);
  if (!isValid) {
    throw new TRPCError({
      code: "UNAUTHORIZED",
      message: "Invalid email or password",
    });
  }

  // Update last signed in
  await db.updateUser(user.id, { lastSignedIn: new Date() });

  // Log activity
  await db.createActivityLog({
    userId: user.id,
    action: "user_login",
    entityType: "user",
    entityId: user.id,
    details: { method: "email" },
  });

  return user;
}

export async function verifyEmail(token: string) {
  const user = await db.getUserByVerificationToken(token);
  
  if (!user) {
    throw new TRPCError({
      code: "NOT_FOUND",
      message: "Invalid verification token",
    });
  }

  if (user.emailVerificationExpires && new Date() > user.emailVerificationExpires) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Verification token has expired. Please request a new one.",
    });
  }

  await db.updateUser(user.id, {
    emailVerified: true,
    emailVerificationToken: null,
    emailVerificationExpires: null,
  });

  // Log activity
  await db.createActivityLog({
    userId: user.id,
    action: "email_verified",
    entityType: "user",
    entityId: user.id,
  });

  return user;
}

export async function requestPasswordReset(email: string) {
  const user = await db.getUserByEmail(email);
  
  if (!user) {
    // Don't reveal if email exists
    return { success: true };
  }

  const resetToken = generateToken();
  const resetExpires = new Date(Date.now() + PASSWORD_RESET_EXPIRY_HOURS * 60 * 60 * 1000);

  await db.updateUser(user.id, {
    passwordResetToken: resetToken,
    passwordResetExpires: resetExpires,
  });

  // Log activity
  await db.createActivityLog({
    userId: user.id,
    action: "password_reset_requested",
    entityType: "user",
    entityId: user.id,
  });

  return {
    success: true,
    resetToken,
    email: user.email,
    userId: user.id,
  };
}

export async function resetPassword(token: string, newPassword: string) {
  const user = await db.getUserByPasswordResetToken(token);
  
  if (!user) {
    throw new TRPCError({
      code: "NOT_FOUND",
      message: "Invalid reset token",
    });
  }

  if (user.passwordResetExpires && new Date() > user.passwordResetExpires) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Reset token has expired. Please request a new one.",
    });
  }

  const passwordHash = await hashPassword(newPassword);

  await db.updateUser(user.id, {
    passwordHash,
    passwordResetToken: null,
    passwordResetExpires: null,
  });

  // Log activity
  await db.createActivityLog({
    userId: user.id,
    action: "password_reset",
    entityType: "user",
    entityId: user.id,
  });

  return user;
}

export async function resendVerificationEmail(email: string) {
  const user = await db.getUserByEmail(email);
  
  if (!user) {
    throw new TRPCError({
      code: "NOT_FOUND",
      message: "User not found",
    });
  }

  if (user.emailVerified) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Email is already verified",
    });
  }

  const verificationToken = generateToken();
  const verificationExpires = new Date(Date.now() + TOKEN_EXPIRY_HOURS * 60 * 60 * 1000);

  await db.updateUser(user.id, {
    emailVerificationToken: verificationToken,
    emailVerificationExpires: verificationExpires,
  });

  return {
    verificationToken,
    email: user.email,
    userId: user.id,
  };
}
