import { createClient } from "@supabase/supabase-js";
import { ENV } from "./_core/env";
import { sendVerificationEmail, sendPasswordResetEmail } from "./email";
import { getDb } from "./db";

// Supabase client for authentication
const supabaseAuth = createClient(
  ENV.supabaseUrl,
  ENV.supabaseServiceRoleKey,
  {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  }
);

export interface AuthUser {
  id: string;
  email: string;
  name?: string;
  role: "admin" | "user";
  emailConfirmed: boolean;
  createdAt: Date;
}

// Register a new user with email/password
export async function registerUser(
  email: string,
  password: string,
  name?: string
): Promise<{ success: boolean; user?: AuthUser; error?: string }> {
  try {
    // Create user in Supabase Auth
    const { data: authData, error: authError } = await supabaseAuth.auth.admin.createUser({
      email,
      password,
      email_confirm: false,
      user_metadata: {
        name: name || email.split("@")[0],
      },
    });

    if (authError) {
      console.error("[Auth] Failed to create user:", authError.message);
      return { success: false, error: authError.message };
    }

    const userId = authData.user?.id;
    if (!userId) {
      return { success: false, error: "Failed to create user" };
    }

    // Create user record in database - store Supabase UUID as string in openId field
    const db = await getDb();
    if (db) {
      const { createUser } = await import("./db");
      await createUser({
        openId: userId,
        email,
        name: name || email.split("@")[0],
        role: "user",
        emailVerified: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      });
    }

    // Send verification email
    await sendVerificationEmail(email, userId, name);

    return {
      success: true,
      user: {
        id: userId,
        email,
        name: name || email.split("@")[0],
        role: "user",
        emailConfirmed: false,
        createdAt: new Date(),
      },
    };
  } catch (error) {
    console.error("[Auth] Error registering user:", error);
    return { success: false, error: String(error) };
  }
}

// Login user with email/password
export async function loginUser(
  email: string,
  password: string
): Promise<{ success: boolean; user?: AuthUser; session?: any; error?: string }> {
  try {
    const { data, error } = await supabaseAuth.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      console.error("[Auth] Login failed:", error.message);
      return { success: false, error: error.message };
    }

    if (!data.user) {
      return { success: false, error: "Login failed" };
    }

    // Get user from database using Supabase UUID
    const { getUserByOpenId } = await import("./db");
    const dbUser = await getUserByOpenId(data.user.id);

    return {
      success: true,
      user: {
        id: data.user.id,
        email: data.user.email || "",
        name: data.user.user_metadata?.name,
        role: dbUser?.role || "user",
        emailConfirmed: !!data.user.email_confirmed_at,
        createdAt: new Date(data.user.created_at),
      },
      session: data.session,
    };
  } catch (error) {
    console.error("[Auth] Error logging in:", error);
    return { success: false, error: String(error) };
  }
}

// Verify email with token
export async function verifyEmail(
  userId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabaseAuth.auth.admin.updateUserById(userId, {
      email_confirm: true,
    });

    if (error) {
      console.error("[Auth] Failed to verify email:", error.message);
      return { success: false, error: error.message };
    }

    // Update database
    const { updateUser } = await import("./db");
    const numUserId = parseInt(userId, 10);
    if (!isNaN(numUserId)) {
      await updateUser(numUserId, { emailVerified: true });
    }

    return { success: true };
  } catch (error) {
    console.error("[Auth] Error verifying email:", error);
    return { success: false, error: String(error) };
  }
}

// Request password reset
export async function requestPasswordReset(
  email: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabaseAuth.auth.admin.generateLink({
      type: "recovery",
      email,
      options: {
        redirectTo: `${process.env.APP_URL}/reset-password`,
      },
    });

    if (error) {
      console.error("[Auth] Failed to generate reset link:", error.message);
      return { success: false, error: error.message };
    }

    // Send password reset email via Brevo
    // Note: Supabase will send the reset link directly, we just notify via Brevo

    return { success: true };
  } catch (error) {
    console.error("[Auth] Error requesting password reset:", error);
    return { success: false, error: String(error) };
  }
}

// Reset password with token
export async function resetPassword(
  userId: string,
  newPassword: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabaseAuth.auth.admin.updateUserById(userId, {
      password: newPassword,
    });

    if (error) {
      console.error("[Auth] Failed to reset password:", error.message);
      return { success: false, error: error.message };
    }

    return { success: true };
  } catch (error) {
    console.error("[Auth] Error resetting password:", error);
    return { success: false, error: String(error) };
  }
}

// Get user by ID
export async function getUserById(userId: string): Promise<AuthUser | null> {
  try {
    const { data, error } = await supabaseAuth.auth.admin.getUserById(userId);

    if (error || !data.user) {
      return null;
    }

    const { getUserByOpenId } = await import("./db");
    const dbUser = await getUserByOpenId(data.user.id);

    return {
      id: data.user.id,
      email: data.user.email || "",
      name: data.user.user_metadata?.name,
      role: dbUser?.role || "user",
      emailConfirmed: !!data.user.email_confirmed_at,
      createdAt: new Date(data.user.created_at),
    };
  } catch (error) {
    console.error("[Auth] Error verifying token:", error);
    return null;
  }
}

// Verify session token
export async function verifySessionToken(token: string): Promise<AuthUser | null> {
  try {
    const { data, error } = await supabaseAuth.auth.getUser(token);

    if (error || !data.user) {
      return null;
    }

    const { getUserByOpenId } = await import("./db");
    const dbUser = await getUserByOpenId(data.user.id);

    return {
      id: data.user.id,
      email: data.user.email || "",
      name: data.user.user_metadata?.name,
      role: dbUser?.role || "user",
      emailConfirmed: !!data.user.email_confirmed_at,
      createdAt: new Date(data.user.created_at),
    };
  } catch (error) {
    console.error("[Auth] Error verifying token:", error);
    return null;
  }
}
