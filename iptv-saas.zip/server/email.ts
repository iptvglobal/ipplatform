import * as db from "./db";

// Email configuration - will use Brevo SMTP
interface EmailConfig {
  brevoApiKey?: string;
  fromEmail: string;
  fromName: string;
  baseUrl: string;
}

let emailConfig: EmailConfig = {
  fromEmail: process.env.BREVO_SENDER_EMAIL || "noreply@iptv-saas.com",
  fromName: process.env.BREVO_SENDER_NAME || "IPTV SaaS",
  baseUrl: process.env.VITE_APP_URL || process.env.APP_URL || "http://localhost:3000",
};

export function setEmailConfig(config: Partial<EmailConfig>) {
  emailConfig = { ...emailConfig, ...config };
}

// Initialize email config from environment
export function initializeEmailConfig() {
  const baseUrl = process.env.VITE_APP_URL || process.env.APP_URL || process.env.NODE_ENV === "production" ? "https://" + (process.env.VERCEL_URL || "localhost:3000") : "http://localhost:3000";
  setEmailConfig({
    fromEmail: process.env.BREVO_SENDER_EMAIL || "noreply@iptv-saas.com",
    fromName: process.env.BREVO_SENDER_NAME || "IPTV SaaS",
    baseUrl,
  });
}

// Template variable replacement
function replaceVariables(template: string, variables: Record<string, string>): string {
  let result = template;
  for (const [key, value] of Object.entries(variables)) {
    result = result.replace(new RegExp(`{{${key}}}`, "g"), value);
  }
  return result;
}

// Send email via Brevo API
export async function sendEmail(
  to: string,
  subject: string,
  htmlContent: string,
  textContent?: string
): Promise<boolean> {
  const brevoApiKey = await getBrevoApiKey();
  
  if (!brevoApiKey) {
    console.log("[Email] Brevo API key not configured. Email would be sent to:", to);
    console.log("[Email] Subject:", subject);
    return true; // Return true in dev mode
  }

  try {
    const response = await fetch("https://api.brevo.com/v3/smtp/email", {
      method: "POST",
      headers: {
        "accept": "application/json",
        "api-key": brevoApiKey,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        sender: {
          name: emailConfig.fromName,
          email: emailConfig.fromEmail,
        },
        to: [{ email: to }],
        subject,
        htmlContent,
        textContent: textContent || undefined,
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("[Email] Failed to send:", error);
      return false;
    }

    console.log("[Email] Sent successfully to:", to);
    return true;
  } catch (error) {
    console.error("[Email] Error sending email:", error);
    return false;
  }
}

async function getBrevoApiKey(): Promise<string | undefined> {
  const setting = await db.getSetting("brevo_api_key");
  return setting?.value || process.env.BREVO_API_KEY;
}

// Send templated email
export async function sendTemplatedEmail(
  templateName: string,
  to: string,
  variables: Record<string, string>
): Promise<boolean> {
  const template = await db.getEmailTemplate(templateName);
  
  if (!template) {
    console.error("[Email] Template not found:", templateName);
    return false;
  }

  const subject = replaceVariables(template.subject, variables);
  const htmlContent = replaceVariables(template.htmlContent, variables);
  const textContent = template.textContent 
    ? replaceVariables(template.textContent, variables)
    : undefined;

  return sendEmail(to, subject, htmlContent, textContent);
}

// Pre-defined email sending functions
export async function sendVerificationEmail(
  email: string,
  token: string,
  name?: string
): Promise<boolean> {
  const verificationUrl = `${emailConfig.baseUrl}/verify-email?token=${token}`;
  
  // Try to use template first
  const sent = await sendTemplatedEmail("email_verification", email, {
    name: name || "User",
    verification_url: verificationUrl,
    token,
  });

  if (sent) return true;

  // Fallback to default template
  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .button { display: inline-block; padding: 12px 24px; background-color: #3b82f6; color: white; text-decoration: none; border-radius: 6px; }
        .footer { margin-top: 30px; font-size: 12px; color: #666; }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>Verify Your Email</h1>
        <p>Hi ${name || "there"},</p>
        <p>Thank you for registering! Please verify your email address by clicking the button below:</p>
        <p><a href="${verificationUrl}" class="button">Verify Email</a></p>
        <p>Or copy and paste this link into your browser:</p>
        <p>${verificationUrl}</p>
        <p>This link will expire in 24 hours.</p>
        <div class="footer">
          <p>If you didn't create an account, you can safely ignore this email.</p>
        </div>
      </div>
    </body>
    </html>
  `;

  return sendEmail(email, "Verify Your Email Address", htmlContent);
}

export async function sendPasswordResetEmail(
  email: string,
  token: string,
  name?: string
): Promise<boolean> {
  const resetUrl = `${emailConfig.baseUrl}/reset-password?token=${token}`;
  
  // Try to use template first
  const sent = await sendTemplatedEmail("password_reset", email, {
    name: name || "User",
    reset_url: resetUrl,
    token,
  });

  if (sent) return true;

  // Fallback to default template
  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .button { display: inline-block; padding: 12px 24px; background-color: #3b82f6; color: white; text-decoration: none; border-radius: 6px; }
        .footer { margin-top: 30px; font-size: 12px; color: #666; }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>Reset Your Password</h1>
        <p>Hi ${name || "there"},</p>
        <p>We received a request to reset your password. Click the button below to create a new password:</p>
        <p><a href="${resetUrl}" class="button">Reset Password</a></p>
        <p>Or copy and paste this link into your browser:</p>
        <p>${resetUrl}</p>
        <p>This link will expire in 1 hour.</p>
        <div class="footer">
          <p>If you didn't request a password reset, you can safely ignore this email.</p>
        </div>
      </div>
    </body>
    </html>
  `;

  return sendEmail(email, "Reset Your Password", htmlContent);
}

export async function sendOrderConfirmationEmail(
  email: string,
  orderNumber: string,
  planName: string,
  totalPrice: string,
  name?: string
): Promise<boolean> {
  const orderUrl = `${emailConfig.baseUrl}/dashboard/orders`;
  
  const sent = await sendTemplatedEmail("order_confirmation", email, {
    name: name || "Customer",
    order_number: orderNumber,
    plan_name: planName,
    total_price: totalPrice,
    order_url: orderUrl,
  });

  if (sent) return true;

  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .order-details { background: #f5f5f5; padding: 15px; border-radius: 6px; margin: 20px 0; }
        .button { display: inline-block; padding: 12px 24px; background-color: #3b82f6; color: white; text-decoration: none; border-radius: 6px; }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>Order Confirmation</h1>
        <p>Hi ${name || "there"},</p>
        <p>Thank you for your order! Here are your order details:</p>
        <div class="order-details">
          <p><strong>Order Number:</strong> ${orderNumber}</p>
          <p><strong>Plan:</strong> ${planName}</p>
          <p><strong>Total:</strong> $${totalPrice}</p>
        </div>
        <p><a href="${orderUrl}" class="button">View Order</a></p>
      </div>
    </body>
    </html>
  `;

  return sendEmail(email, `Order Confirmation - ${orderNumber}`, htmlContent);
}

export async function sendPaymentVerifiedEmail(
  email: string,
  orderNumber: string,
  name?: string
): Promise<boolean> {
  const dashboardUrl = `${emailConfig.baseUrl}/dashboard`;
  
  const sent = await sendTemplatedEmail("payment_verified", email, {
    name: name || "Customer",
    order_number: orderNumber,
    dashboard_url: dashboardUrl,
  });

  if (sent) return true;

  const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .success { color: #10b981; }
        .button { display: inline-block; padding: 12px 24px; background-color: #10b981; color: white; text-decoration: none; border-radius: 6px; }
      </style>
    </head>
    <body>
      <div class="container">
        <h1 class="success">Payment Verified!</h1>
        <p>Hi ${name || "there"},</p>
        <p>Great news! Your payment for order <strong>${orderNumber}</strong> has been verified.</p>
        <p>Your IPTV credentials are now available in your dashboard.</p>
        <p><a href="${dashboardUrl}" class="button">Go to Dashboard</a></p>
      </div>
    </body>
    </html>
  `;

  return sendEmail(email, `Payment Verified - ${orderNumber}`, htmlContent);
}

// Initialize default email templates
export async function initializeEmailTemplates() {
  const templates = [
    {
      name: "email_verification",
      subject: "Verify Your Email Address",
      htmlContent: "<!DOCTYPE html><html><head><style>body{font-family:Arial,sans-serif;line-height:1.6;color:#333}.container{max-width:600px;margin:0 auto;padding:20px}.button{display:inline-block;padding:12px 24px;background-color:#3b82f6;color:white;text-decoration:none;border-radius:6px}.footer{margin-top:30px;font-size:12px;color:#666}</style></head><body><div class='container'><h1>Verify Your Email</h1><p>Hi {{name}},</p><p>Thank you for registering! Please verify your email address by clicking the button below:</p><p><a href='{{verification_url}}' class='button'>Verify Email</a></p><p>This link will expire in 24 hours.</p><div class='footer'><p>If you did not create an account, you can safely ignore this email.</p></div></div></body></html>",
      variables: ["name", "verification_url", "token"],
    },
    {
      name: "password_reset",
      subject: "Reset Your Password",
      htmlContent: "<!DOCTYPE html><html><head><style>body{font-family:Arial,sans-serif;line-height:1.6;color:#333}.container{max-width:600px;margin:0 auto;padding:20px}.button{display:inline-block;padding:12px 24px;background-color:#3b82f6;color:white;text-decoration:none;border-radius:6px}.footer{margin-top:30px;font-size:12px;color:#666}</style></head><body><div class='container'><h1>Reset Your Password</h1><p>Hi {{name}},</p><p>We received a request to reset your password. Click the button below to create a new password:</p><p><a href='{{reset_url}}' class='button'>Reset Password</a></p><p>This link will expire in 1 hour.</p><div class='footer'><p>If you did not request a password reset, you can safely ignore this email.</p></div></div></body></html>",
      variables: ["name", "reset_url", "token"],
    },
    {
      name: "order_confirmation",
      subject: "Order Confirmation - {{order_number}}",
      htmlContent: "<!DOCTYPE html><html><head><style>body{font-family:Arial,sans-serif;line-height:1.6;color:#333}.container{max-width:600px;margin:0 auto;padding:20px}.order-details{background:#f5f5f5;padding:15px;border-radius:6px;margin:20px 0}.button{display:inline-block;padding:12px 24px;background-color:#3b82f6;color:white;text-decoration:none;border-radius:6px}</style></head><body><div class='container'><h1>Order Confirmation</h1><p>Hi {{name}},</p><p>Thank you for your order! Here are your order details:</p><div class='order-details'><p><strong>Order Number:</strong> {{order_number}}</p><p><strong>Plan:</strong> {{plan_name}}</p><p><strong>Total:</strong> ${{total_price}}</p></div><p><a href='{{order_url}}' class='button'>View Order</a></p></div></body></html>",
      variables: ["name", "order_number", "plan_name", "totalPrice", "order_url"],
    },
    {
      name: "payment_verified",
      subject: "Payment Verified - {{order_number}}",
      htmlContent: "<!DOCTYPE html><html><head><style>body{font-family:Arial,sans-serif;line-height:1.6;color:#333}.container{max-width:600px;margin:0 auto;padding:20px}.success{color:#10b981}.button{display:inline-block;padding:12px 24px;background-color:#10b981;color:white;text-decoration:none;border-radius:6px}</style></head><body><div class='container'><h1 class='success'>Payment Verified!</h1><p>Hi {{name}},</p><p>Great news! Your payment for order <strong>{{order_number}}</strong> has been verified.</p><p>Your IPTV credentials are now available in your dashboard.</p><p><a href='{{dashboard_url}}' class='button'>Go to Dashboard</a></p></div></body></html>",
      variables: ["name", "order_number", "dashboard_url"],
    },
  ];

  for (const template of templates) {
    await db.upsertEmailTemplate({
      name: template.name,
      subject: template.subject,
      htmlContent: template.htmlContent,
      variables: template.variables,
    });
  }
}
