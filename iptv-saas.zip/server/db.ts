import { eq, desc, and, sql, gte, lte } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  subscriptionPlans, InsertSubscriptionPlan,
  paymentMethods, InsertPaymentMethod,
  planPaymentLinks, InsertPlanPaymentLink,
  orders, InsertOrder,
  iptvCredentials, InsertIptvCredential,
  chatConversations, InsertChatConversation,
  chatMessages, InsertChatMessage,
  emailTemplates, InsertEmailTemplate,
  activityLogs, InsertActivityLog,
  systemSettings, InsertSystemSetting
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ==================== USER OPERATIONS ====================

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId || !user.email) {
    throw new Error("User openId and email are required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
      email: user.email,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "passwordHash", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }
    if (user.emailVerified !== undefined) {
      values.emailVerified = user.emailVerified;
      updateSet.emailVerified = user.emailVerified;
    }
    if (user.emailVerificationToken !== undefined) {
      values.emailVerificationToken = user.emailVerificationToken;
      updateSet.emailVerificationToken = user.emailVerificationToken;
    }
    if (user.emailVerificationExpires !== undefined) {
      values.emailVerificationExpires = user.emailVerificationExpires;
      updateSet.emailVerificationExpires = user.emailVerificationExpires;
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createUser(user: InsertUser) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(users).values(user);
  return result[0].insertId;
}

export async function updateUser(id: number, data: Partial<InsertUser>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(users).set({ ...data, updatedAt: new Date() }).where(eq(users.id, id));
}

export async function getUserByVerificationToken(token: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.emailVerificationToken, token)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserByPasswordResetToken(token: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.passwordResetToken, token)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllUsers(limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(users).orderBy(desc(users.createdAt)).limit(limit).offset(offset);
}

export async function getUserCount() {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql<number>`count(*)` }).from(users);
  return result[0]?.count ?? 0;
}

// ==================== SUBSCRIPTION PLAN OPERATIONS ====================

export async function getActivePlans() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(subscriptionPlans).where(eq(subscriptionPlans.isActive, true)).orderBy(subscriptionPlans.sortOrder);
}

export async function getAllPlans() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(subscriptionPlans).orderBy(subscriptionPlans.sortOrder);
}

export async function getPlanById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createPlan(plan: InsertSubscriptionPlan) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(subscriptionPlans).values(plan);
  return result[0].insertId;
}

export async function updatePlan(id: number, data: Partial<InsertSubscriptionPlan>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(subscriptionPlans).set({ ...data, updatedAt: new Date() }).where(eq(subscriptionPlans.id, id));
}

export async function deletePlan(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(subscriptionPlans).where(eq(subscriptionPlans.id, id));
}

// ==================== PAYMENT METHOD OPERATIONS ====================

export async function getActivePaymentMethods() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(paymentMethods).where(eq(paymentMethods.isActive, true)).orderBy(paymentMethods.sortOrder);
}

export async function getAllPaymentMethods() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(paymentMethods).orderBy(paymentMethods.sortOrder);
}

export async function getPaymentMethodById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(paymentMethods).where(eq(paymentMethods.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createPaymentMethod(method: InsertPaymentMethod) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(paymentMethods).values(method);
  return result[0].insertId;
}

export async function updatePaymentMethod(id: number, data: Partial<InsertPaymentMethod>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(paymentMethods).set({ ...data, updatedAt: new Date() }).where(eq(paymentMethods.id, id));
}

export async function deletePaymentMethod(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(paymentMethods).where(eq(paymentMethods.id, id));
}

// ==================== PLAN PAYMENT LINK OPERATIONS ====================

export async function getPlanPaymentLinks(planId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(planPaymentLinks).where(eq(planPaymentLinks.planId, planId));
}

export async function upsertPlanPaymentLink(link: InsertPlanPaymentLink) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await db.select().from(planPaymentLinks)
    .where(and(
      eq(planPaymentLinks.planId, link.planId),
      eq(planPaymentLinks.paymentMethodId, link.paymentMethodId)
    )).limit(1);
  
  if (existing.length > 0) {
    await db.update(planPaymentLinks)
      .set({ customLink: link.customLink, customInstructions: link.customInstructions, updatedAt: new Date() })
      .where(eq(planPaymentLinks.id, existing[0].id));
    return existing[0].id;
  } else {
    const result = await db.insert(planPaymentLinks).values(link);
    return result[0].insertId;
  }
}

export async function deletePlanPaymentLink(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(planPaymentLinks).where(eq(planPaymentLinks.id, id));
}

// ==================== ORDER OPERATIONS ====================

export async function createOrder(order: InsertOrder) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(orders).values(order);
  return result[0].insertId;
}

export async function getOrderById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getOrderByNumber(orderNumber: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(orders).where(eq(orders.orderNumber, orderNumber)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getOrderByCryptoPaymentId(cryptoPaymentId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(orders).where(eq(orders.cryptoPaymentId, cryptoPaymentId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserOrders(userId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt)).limit(limit);
}

export async function getAllOrders(limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders).orderBy(desc(orders.createdAt)).limit(limit).offset(offset);
}

export async function getOrdersByStatus(status: string) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders).where(eq(orders.status, status as any)).orderBy(desc(orders.createdAt));
}

export async function updateOrder(id: number, data: Partial<InsertOrder>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(orders).set({ ...data, updatedAt: new Date() }).where(eq(orders.id, id));
}

export async function getOrderCount() {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ count: sql<number>`count(*)` }).from(orders);
  return result[0]?.count ?? 0;
}

export async function getTotalRevenue() {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select({ total: sql<number>`COALESCE(SUM(totalPrice), 0)` }).from(orders)
    .where(eq(orders.status, 'paid'));
  return result[0]?.total ?? 0;
}

// ==================== IPTV CREDENTIAL OPERATIONS ====================

export async function createCredential(credential: InsertIptvCredential) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(iptvCredentials).values(credential);
  return result[0].insertId;
}

export async function getCredentialById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(iptvCredentials).where(eq(iptvCredentials.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserCredentials(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(iptvCredentials).where(eq(iptvCredentials.userId, userId)).orderBy(desc(iptvCredentials.createdAt));
}

export async function getOrderCredentials(orderId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(iptvCredentials).where(eq(iptvCredentials.orderId, orderId));
}

export async function getAllCredentials(limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(iptvCredentials).orderBy(desc(iptvCredentials.createdAt)).limit(limit).offset(offset);
}

export async function updateCredential(id: number, data: Partial<InsertIptvCredential>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(iptvCredentials).set({ ...data, updatedAt: new Date() }).where(eq(iptvCredentials.id, id));
}

export async function deleteCredential(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(iptvCredentials).where(eq(iptvCredentials.id, id));
}

// ==================== CHAT OPERATIONS ====================

export async function getOrCreateConversation(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await db.select().from(chatConversations)
    .where(and(eq(chatConversations.userId, userId), eq(chatConversations.status, 'open')))
    .limit(1);
  
  if (existing.length > 0) return existing[0];
  
  const result = await db.insert(chatConversations).values({ userId });
  const newConv = await db.select().from(chatConversations).where(eq(chatConversations.id, result[0].insertId)).limit(1);
  return newConv[0];
}

export async function getConversationById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(chatConversations).where(eq(chatConversations.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllConversations() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(chatConversations).orderBy(desc(chatConversations.lastMessageAt));
}

export async function updateConversation(id: number, data: Partial<InsertChatConversation>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(chatConversations).set({ ...data, updatedAt: new Date() }).where(eq(chatConversations.id, id));
}

export async function createMessage(message: InsertChatMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(chatMessages).values(message);
  await db.update(chatConversations).set({ lastMessageAt: new Date() }).where(eq(chatConversations.id, message.conversationId));
  return result[0].insertId;
}

export async function getConversationMessages(conversationId: number, limit = 100) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(chatMessages).where(eq(chatMessages.conversationId, conversationId)).orderBy(chatMessages.createdAt).limit(limit);
}

export async function markMessagesAsRead(conversationId: number, senderRole: 'user' | 'admin') {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const oppositeRole = senderRole === 'user' ? 'admin' : 'user';
  await db.update(chatMessages).set({ isRead: true })
    .where(and(eq(chatMessages.conversationId, conversationId), eq(chatMessages.senderRole, oppositeRole)));
}

// ==================== EMAIL TEMPLATE OPERATIONS ====================

export async function getEmailTemplate(name: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(emailTemplates).where(eq(emailTemplates.name, name)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getAllEmailTemplates() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(emailTemplates).orderBy(emailTemplates.name);
}

export async function upsertEmailTemplate(template: InsertEmailTemplate) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await db.select().from(emailTemplates).where(eq(emailTemplates.name, template.name)).limit(1);
  
  if (existing.length > 0) {
    await db.update(emailTemplates)
      .set({ ...template, updatedAt: new Date() })
      .where(eq(emailTemplates.id, existing[0].id));
    return existing[0].id;
  } else {
    const result = await db.insert(emailTemplates).values(template);
    return result[0].insertId;
  }
}

// ==================== ACTIVITY LOG OPERATIONS ====================

export async function createActivityLog(log: InsertActivityLog) {
  const db = await getDb();
  if (!db) return;
  await db.insert(activityLogs).values(log);
}

export async function getActivityLogs(limit = 100, offset = 0) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(activityLogs).orderBy(desc(activityLogs.createdAt)).limit(limit).offset(offset);
}

export async function getUserActivityLogs(userId: number, limit = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(activityLogs).where(eq(activityLogs.userId, userId)).orderBy(desc(activityLogs.createdAt)).limit(limit);
}

// ==================== SYSTEM SETTINGS OPERATIONS ====================

export async function getSetting(key: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(systemSettings).where(eq(systemSettings.key, key)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function upsertSetting(setting: InsertSystemSetting) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await db.select().from(systemSettings).where(eq(systemSettings.key, setting.key)).limit(1);
  
  if (existing.length > 0) {
    await db.update(systemSettings)
      .set({ value: setting.value, type: setting.type, description: setting.description, updatedAt: new Date() })
      .where(eq(systemSettings.id, existing[0].id));
    return existing[0].id;
  } else {
    const result = await db.insert(systemSettings).values(setting);
    return result[0].insertId;
  }
}

export async function getAllSettings() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(systemSettings);
}


// ==================== NOTIFICATION OPERATIONS ====================

export async function createNotification(data: {
  userId: number;
  type: string;
  message: string;
  data: string;
  read: boolean;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(activityLogs).values({
    userId: data.userId,
    action: data.type,
    entityType: "notification",
    entityId: 0,
    details: { message: data.message, ...JSON.parse(data.data) },
  });
  
  return result[0].insertId;
}

export async function updateNotification(notificationId: number, data: { read: boolean }) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Activity logs don't have updatedAt, just mark as processed
  // In a real system, you'd have a separate notifications table
}

export async function getUserNotifications(userId: number, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select()
    .from(activityLogs)
    .where(eq(activityLogs.userId, userId))
    .orderBy(desc(activityLogs.createdAt))
    .limit(limit);
}

export async function getUnreadNotificationCount(userId: number): Promise<number> {
  const db = await getDb();
  if (!db) return 0;
  
  const result = await db.select()
    .from(activityLogs)
    .where(eq(activityLogs.userId, userId));
  
  return result.length;
}

export async function getUsersByRole(role: "admin" | "user") {
  const db = await getDb();
  if (!db) return [];
  
  return db.select().from(users).where(eq(users.role, role));
}


// ==================== CREDENTIAL ASSIGNMENT OPERATIONS ====================

export async function getVerifiedOrdersWithoutCredentials() {
  const db = await getDb();
  if (!db) return [];
  
  return db.select()
    .from(orders)
    .where(eq(orders.status, "verified"))
    .limit(100);
}

export async function assignCredentialToOrder(orderId: number, credentialId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Update order with credential
  await db.update(orders)
    .set({ iptvCredentialId: credentialId })
    .where(eq(orders.id, orderId));
}

export async function removeCredentialFromOrder(orderId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(orders)
    .set({ iptvCredentialId: null })
    .where(eq(orders.id, orderId));
}

export async function getIptvCredentialsByType(credentialType: string) {
  const db = await getDb();
  if (!db) return [];
  
  return db.select()
    .from(iptvCredentials)
    .where(eq(iptvCredentials.type, credentialType as any))
    .orderBy(asc(iptvCredentials.usedConnections));
}

export async function updateIptvCredential(credentialId: number, data: Partial<typeof iptvCredentials.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  await db.update(iptvCredentials)
    .set({ ...data, updatedAt: new Date() })
    .where(eq(iptvCredentials.id, credentialId));
}
