import { describe, expect, it } from "vitest";
import { ENV } from "./_core/env";

describe("Email URL Configuration", () => {
  it("should have APP_URL configured", () => {
    const appUrl = process.env.APP_URL;
    expect(appUrl).toBeDefined();
    expect(appUrl).not.toBe("");
  });

  it("should have valid URL format", () => {
    const appUrl = process.env.APP_URL;
    if (appUrl) {
      expect(appUrl).toMatch(/^https?:\/\//);
    }
  });

  it("should not have localhost in production", () => {
    if (process.env.NODE_ENV === "production") {
      const appUrl = process.env.APP_URL;
      expect(appUrl).not.toContain("localhost");
    }
  });

  it("should generate correct verification URL", () => {
    const appUrl = process.env.APP_URL || "http://localhost:3000";
    const token = "test-token-123";
    const verificationUrl = `${appUrl}/verify-email?token=${token}`;
    
    expect(verificationUrl).toContain("/verify-email?token=");
    expect(verificationUrl).toContain(token);
  });
});
